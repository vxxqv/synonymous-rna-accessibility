# Independent PERSIST numerical audit, frozen before observed answers

This evaluator is separately authored and imports no function from the author implementation. Only the protocol and AST-extracted input/output schemas of `persist_prediction.py` were read. No observed target table, feature artifact, development prediction or validation result was opened while preparing this freeze. The current stage is synthetic only. An explicit later root authorization with artifact paths and hashes is required before any observed reconstruction.

## Fixed assertion

Reconstruct the six declared models for the fixed 22 development and 15 holdout IDs. Use the same 15 development groups and feature widths 21, 82 and 83, with penalties 0.1, 1, 10 and 100. Compare all six holdout prediction vectors, all three ridge CV grids and selected penalties, every OOF prediction, the nearest-CDS tie sets, all primary and secondary metrics, and all 15 influence records and gain ranges. Stop on a mismatch or missing required row. Do not alter a model, tolerance, split, feature or target after inspecting author answers.

The approved 37-row feature artifact, including MUP, is a specified input. The audit does not refold sequences, independently recover partition functions, recompute sequence frequencies, validate RNA-engine binaries or establish cellular structural interpretation. CDS-only metadata supports a separately calculated Hamming-distance baseline. Selected numeric targets support numerical reproduction; their source-table parsing and endpoint-unit provenance remain external dependencies.

## Separate numerical formulation

Within each development fold, remove precisely the columns whose training entries are all exactly equal. Compute training means and population standard deviations on the remaining columns. Transform omitted or holdout rows with those training quantities. No omitted-group or holdout value determines a transform, selected penalty or coefficient.

With transformed training matrix Z, solve the unpenalized-intercept ridge objective

`min_(b,beta) ||y - b*1 - Z*beta||^2 + lambda*||beta||^2`

by SVD least squares on the augmented design `[1 Z; 0 sqrt(lambda)I]` and response `[y; 0]`. This is independent of a primal normal-equation implementation. The exact constant-response minimizer is handled directly with zero coefficients; an all-constant feature matrix yields its unpenalized response mean. Synthetic comparisons use a separate n-by-n dual ridge solve with independently calculated training moments.

For every penalty, assemble OOF predictions in the original 22-row order. The CV loss is total absolute error divided by 22, not a mean over equally weighted groups. Select the largest penalty whose loss is at most the minimum plus `1e-12 * (max(y_dev)-min(y_dev))`. At zero response range, eligible losses must equal the minimum exactly. Refit the selected model on all 22 development rows.

The other three models are the development median, development mean and nearest development CDS. Hamming distance is computed directly after uppercase T-to-U normalization. Every minimum-distance development tie contributes equally to its response average. The frozen identifiers and model order are retained.

## Evaluation and failure criteria

MAE and RMSE are separately calculated from the 15 fixed residuals. Spearman agreement uses explicitly constructed average ranks for exact ties; it is undefined when either vector is constant. No tolerance is used to merge close ranks. Negative and zero responses are retained.

The primary model must have MAE at most 0.9 times each of the five baseline MAEs, with every baseline MAE strictly positive. A zero-error baseline produces an undefined fractional gain and makes success false, even if the primary also has zero error. All 15 omissions are evaluated without refitting or model selection. Each omission uses the other 14 errors; its gain, decision, zero-baseline status and the complete gain ranges are retained. These are dependent sensitivity diagnostics, not confidence intervals.

Comparison tolerances are fixed before observed inputs. Response-unit quantities use `atol=1e-10*max(1,max|y_dev|,max|y_holdout|)` and `rtol=1e-9`. Dimensionless rank agreement, fractional gains and influence gain ranges instead use `atol=1e-12, rtol=1e-10`, regardless of response scale. Penalty selection, nearest-neighbor distances/tie membership, Boolean decisions, identifier order, dictionary coverage and undefined statuses must agree exactly. No tolerance repairs a different selected model or a different operational success decision.

Only the known validation provenance fields `prediction_freeze` and `protocol_sha256` are separated from the scientific payload. The prediction protocol, feature and implementation hashes and `holdout_targets_read=false` are checked. Historical Git event authentication remains root's separate responsibility. Fresh independent predictions are computed and written before author numeric prediction or validation files are decoded, so the comparator cannot tune toward those answers.

## Synthetic evidence and scope

The authoritative synthetic receipt is `synthetic_v2/receipt.json`: 12 tests passed. It covers a hand-computable ridge optimum, 16 SVD/dual equivalence fits under collinearity, all 12 model/penalty OOF arrays on the frozen 15-group layout, independent holdout ridge predictions, training-only transforms, all-development nearest-CDS ties, exact and near rank ties, constant responses, the response-scaled penalty tie rule, all-zero baselines, all 15 influence records, omission-created undefined gains, coverage failures, nonfinite responses, and refusal to decode inputs before authorization. It also prevents response-unit tolerances from masking wrong dimensionless metrics. All randomness is confined to declared synthetic fixtures with NumPy default_rng seeds 1367 and 20261025.

The first 11-test version passed before adding the dimensionless-tolerance safeguard. Its original source, tests and receipt are preserved under `history/pre_unit_tolerance/`; it is not the authoritative current freeze. No observed result prompted the adjustment. `synthetic_v1/` also remains historical. Finite tests corroborate numerical implementation, not biological validity or a general predictive theorem.

## Later authorized command and inputs

Run only after root explicitly authorizes observed reads:

```text
python -I -B evaluator.py --protocol PROTOCOL_JSON --authorization AUTHORIZATION_JSON --out NEW_DIRECTORY
```

The output directory must be new. Optimized Python is rejected. The authorization must say `status=authorized_by_root`, `operation=independent_PERSIST_prediction_v2_compare`, pin this evaluator's SHA256 and the frozen protocol SHA256, and list exactly five artifacts with explicit paths and hashes: `features`, `cds`, `selected_targets`, `author_predictions`, and `author_validation`. All hashes are checked before numeric decoding. No combined source table is accepted by this interface.

`features` uses the fixed author artifact schema: `ids`, `names`, `values`, `diagnostics`, `protocol_sha256`. `cds` must contain only `cds_by_id`, mapping the 37 fixed IDs to their CDS strings. `selected_targets` must contain only `endpoint`, `development_targets` and `holdout_targets`, with exactly the declared endpoint and all 22/15 selected IDs. The last two artifacts are the frozen author prediction and validation JSON files. There is no automatic search, default observed-data path, fallback, imputation, row exclusion or outcome-dependent alternate model.

Any substantive mismatch returns nonzero and preserves a failure receipt together with the independently reconstructed outputs. A passing comparison records every input hash before and after, numeric comparison counts and tolerances. This task stops at the freeze until explicit observed-read authorization arrives.
