# Independent PERSIST result audit

**Verdict:** numerical reconstruction passed; the frozen primary predictive hypothesis failed. No substantive prediction, selection, metric, coverage or input-hash discrepancy was found. The failed target is retained without retuning.

## Authorization, separation and finite checks

The observed comparison used only the five artifacts authorized by root in `work/persist_cycle3/independent_inputs_v2/authorization.json`, SHA256 `195143964b560bb88316347c8b91c4599905ec1a714801a3b322e2556853ee62`. The protocol remained SHA256 `a3dc686a23acaa12af2f2f44154b8baac819cb6df3a0a6d81328dd3ebdc5fd24`. The evaluator remained its pre-outcome frozen SHA256 `0711ae066da3c443312451e42fcbb651fad8280e5d7173838c3787b3990a1bd0`. No source, tolerance or model was changed after the observed authorization.

The evaluator computed and saved its own predictions and evaluation before decoding author prediction or validation values. It used augmented SVD least squares, separately calculated training-only preparation, the fixed 15 development groups, and its own rank and error calculations. It imported no author implementation. The combined source table was not opened; only the selected endpoint artifact and the other explicitly authorized files were used. Root separately reported re-extraction of the 37 endpoint cells and a prediction commit `a6a2ded62c3fd7581f04cff29d490fbb8796b9d2` before holdout reads. That chronology is supplied provenance, not a Git event independently queried by this numerical audit.

The complete 22-development/15-holdout cohort was reconstructed. All six 15-row prediction vectors, all three four-penalty CV loss grids, all three four-penalty OOF prediction arrays, all nearest-CDS distances and ties, all primary and secondary summaries, all 15 influence records and all gain ranges agreed within the prespecified tolerance. Each ridge selected penalty 100 exactly. All model-selection choices, decisions, identifier orders and undefined statuses agreed exactly.

The maximum absolute holdout-prediction difference was `1.6653345369377348e-16`. The maximum OOF-prediction difference was `2.2412627309620348e-14`; the maximum validation-payload numeric difference was `1.5098599454033135e-15`. These are below the predeclared response-unit tolerance. Dimensionless rank and gain comparisons used their separately frozen tolerance. All five artifact hashes were unchanged after reconstruction. The authoritative run receipt is `observed_v1/receipt.json`.

## All fixed-model results

Errors retain the deposited numeric endpoint units. Spearman agreement is undefined for the two constant predictors.

| Model | MAE | RMSE | Spearman |
|---|---:|---:|---:|
| Development median | 0.0333687323260740 | 0.0383103775474749 | Undefined |
| Development mean | 0.0334611758800762 | 0.0384565515709521 | Undefined |
| Composition ridge | 0.0301389191526551 | 0.0369784069916096 | 0.0892857142857143 |
| Codon/composition ridge | 0.0314792831575021 | 0.0379784463308684 | 0.0107142857142857 |
| Nearest CDS | 0.0402605415270998 | 0.0470382343557261 | 0.0628943256783285 |
| Primary codon/composition/MUP ridge | 0.0314418118422043 | 0.0379404297038286 | 0.0107142857142857 |

The primary model's fractional MAE gains against the five fixed baselines were:

| Baseline | Primary fractional gain |
|---|---:|
| Development median | 0.0577462897013906 |
| Development mean | 0.0603494642599891 |
| Composition ridge | -0.0432295757837254 |
| Codon/composition ridge | 0.0011903484304345 |
| Nearest CDS | 0.2190415069047066 |

Every baseline MAE was positive, so none of these gains is undefined. The requirement was at least a 10% improvement against every baseline. Only the nearest-CDS comparison exceeded that hurdle. The primary model is 4.323% worse than the best baseline, composition ridge. Its 0.119% gain over the codon/composition control is a small descriptive increment and does not meet the frozen success rule.

## All omission diagnostics

All 15 dependent leave-one-holdout-row-out records were retained. Their fractional-gain ranges were:

| Baseline | Minimum | Maximum | Undefined omissions |
|---|---:|---:|---:|
| Development median | 0.0243513290885881 | 0.0850860146155932 | 0 |
| Development mean | 0.0266522952906282 | 0.0873733657660887 | 0 |
| Composition ridge | -0.0612527910563606 | -0.0233975130063065 | 0 |
| Codon/composition ridge | 0.0003898497479688 | 0.0015558800645063 | 0 |
| Nearest CDS | 0.1594036830597696 | 0.2677706879837088 | 0 |

The primary remains worse than composition ridge under every single-row omission. All 15 omission decisions fail the same complete-baseline success rule. These are sensitivity checks on overlapping subsets, not 15 independent validation experiments, confidence intervals or grounds to remove a row.

## Interpretation, limits and next action

The safe conclusion is a failed incremental-prediction hypothesis for this fixed feature, model class, endpoint and selected transfer cohort. Numerical agreement does not show that the feature has no biological relevance, establish a cellular folding mechanism, or calibrate the deposited coefficient as a rate or half-life. No confidence interval, p-value or gene-level independence claim is supported. There is one reporter/context/study, shared design ancestry, nonrandom prefix transfer, a processing-based cohort flag and unresolved biological preparation identity.

The 37 fixed feature rows, including MUP, were specified inputs. This evaluator did not refold the sequences or independently reconstruct feature-engine provenance. Selected endpoint values were independently re-extracted by root, not parsed again from the combined table by this evaluator. Those feature and parsing dependencies are distinct from the independent regression and metric calculations checked here.

Next action: preserve and integrate the failed result, the immutable prediction freeze and this independent receipt. No model, feature, penalty grid, row subset, response transformation or endpoint should be changed in response to this failure. This bounded numerical task is complete and stops here.

## Output identities

| File | SHA256 |
|---|---|
| `observed_v1/receipt.json` | `c46d8a28640f709d7728402e07e36de102eb84de191d82c920223cec4ae984fc` |
| `observed_v1/independent_predictions.json` | `abc1c1c90f4ebb94813c948a86f9f20cbdbd128de96f8f9875320f9a1e600baf` |
| `observed_v1/independent_validation.json` | `6b14de5c30ba81e86fa537e75dac3b9cbfcf77885eac0d810f1faa5c89bab91b` |

All writes remain within `work/persist_cycle3/independent_result_review/`. No repository, manuscript, author result, target input or shared source was edited; no commit or external action was performed.
