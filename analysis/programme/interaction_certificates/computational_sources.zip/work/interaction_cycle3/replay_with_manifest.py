"""Preserve the first receipt and record a fully timed, hash-checked replay."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import sys
import time
sys.dont_write_bytecode = True
base = Path(__file__).resolve().parent
root = base.parents[1]
frozen = json.loads((base/'freeze.json').read_text())
inputs = dict(frozen['input_sha256'])
inputs[str(Path(__file__).resolve().relative_to(root))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
for path, expected in inputs.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected
if (base/'replay_results.json').exists() or (base/'manifest.json').exists():
    raise FileExistsError('Preserve existing replay evidence')
started = datetime.now(timezone.utc).isoformat()
timer = time.perf_counter()
spec = importlib.util.spec_from_file_location('a3_replay', base/'verify_interactions.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
result = {'named_examples': module.named_examples(), 'finite_suite': module.verify_suite(),
          'maxcut_reduction_checks': module.maxcut_checks(), 'counts': dict(module.COUNTS)}
elapsed = time.perf_counter()-timer
result = json.loads(json.dumps(result, default=str))
original = json.loads((base/'results.json').read_text())
assert all(original[k] == result[k] for k in result)
module.dump(base/'replay_results.json', result)
for path, expected in inputs.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected
output = str((base/'replay_results.json').relative_to(root))
manifest = {
 'schema_version': 2, 'claim_id': 'A3_STRUCTURED_INTERACTION_CERTIFICATES_V1_REPLAY',
 'repository': {'commit': 'e9846dca9f74b2c5c34e984eed970e996b9df2bf', 'dirty': False},
 'command': [sys.executable, str(Path(__file__).resolve())],
 'environment': {'software': [{'name': 'Python', 'version': platform.python_version()}], 'hardware': platform.platform()+'; '+platform.machine()},
 'mathematics': {'assertion_tested': 'Replay all frozen finite assertions and compare every stored mathematical result with the preserved first receipt',
  'coefficient_domain': 'Exact integer and Fraction arithmetic', 'conventions': 'contract.json and claim_and_proof.md',
  'inputs': list(inputs), 'bounds': {'finite_fields': 2818, 'small_maxcut_graphs': 75, 'large_implicit_factors': 32},
  'non_claims': ['Universal claims require proofs', 'No new algorithmic priority', 'No independent authorship of replay']},
 'randomness': {'used': True, 'generator': 'Python random.Random', 'seed': 271828},
 'run': {'started_at': started, 'runtime_seconds': elapsed, 'exit_status': 0, 'status': 'completed',
  'resource_limits': {'memory_bytes': None, 'cpu_seconds': None, 'max_cores': 1, 'max_threads': 1}},
 'outputs': [{'path': output, 'sha256': module.sha(base/'replay_results.json'), 'kind': 'result'}],
 'checks': ['Exact equality to every mathematical result in results.json', 'All source hashes unchanged', result['counts']],
 'result': 'Implementation and frozen finite assertions verified; fresh proof review pending',
 'residual_risks': ['Known generic abstraction and variable-elimination principles', 'External cubic MaxCut theorem not reproved'],
 'input_artifacts': [{'path': p, 'sha256': h, 'sha256_after': module.sha(root/p)} for p, h in inputs.items()],
 'declared_results': [output]
}
module.dump(base/'manifest.json', manifest)
print(json.dumps({'status': 'completed', 'runtime_seconds': elapsed, 'same_mathematical_results': True}))
