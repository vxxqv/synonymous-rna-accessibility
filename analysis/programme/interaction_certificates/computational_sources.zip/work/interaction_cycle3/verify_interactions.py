"""Exact bounded A3 certificate verification; no empirical inputs."""
import argparse
from collections import Counter, deque
from datetime import datetime, timezone
from fractions import Fraction as Q
from heapq import heappush, heappop
import hashlib
import importlib.util
import itertools as it
import json
import platform
from pathlib import Path
import random
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT/'outputs/synonymous-rna-accessibility/src/product_closure.py'
spec = importlib.util.spec_from_file_location('additive_a3', SOURCE)
additive = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = additive
spec.loader.exec_module(additive)
INPUTS = [Path(__file__).resolve(), HERE/'contract.json', HERE/'claim_and_proof.md', HERE/'primary_prior.md', SOURCE]
COUNTS = Counter()
P3 = ((1,), (0, 2), (1,))
K2 = ((1,), (0,))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True, default=str)+'\n', encoding='utf-8')


def field(unary, pairs, z):
    return sum((unary[i][v] for i, v in enumerate(z)), Q(0)) + sum(
        (table[z[i]][z[j]] for (i, j), table in pairs.items()), Q(0))


def max_sum(unary, pairs, fixed=None, sign=1):
    """Exact max-sum elimination in supplied natural variable order."""
    d = len(unary)
    fixed = fixed or {}
    domains = [tuple([fixed[i]]) if i in fixed else tuple(range(len(v))) for i, v in enumerate(unary)]
    assert all(0 <= fixed[i] < len(unary[i]) for i in fixed)
    factors = [((i,), {(v,): sign*Q(score) for v, score in enumerate(values)}) for i, values in enumerate(unary)]
    factors += [((i, j), {(u, v): sign*Q(table[u][v]) for u in range(len(unary[i])) for v in range(len(unary[j]))})
                for (i, j), table in pairs.items()]
    stats = Counter(calls=1)
    for var in range(d):
        bucket = [factor for factor in factors if var in factor[0]]
        factors = [factor for factor in factors if var not in factor[0]]
        scope = tuple(sorted(set().union(*(set(s) for s, _ in bucket))))
        rest = tuple(i for i in scope if i != var)
        stats['maximum_bucket_scope'] = max(stats['maximum_bucket_scope'], len(scope))
        entries = 1
        for i in scope:
            entries *= len(domains[i])
        stats['maximum_bucket_assignments'] = max(stats['maximum_bucket_assignments'], entries)
        stats['evaluated_bucket_assignments'] += entries
        table = {}
        for values in it.product(*(domains[i] for i in rest)):
            assignment = dict(zip(rest, values))
            best = None
            for v in domains[var]:
                assignment[var] = v
                score = sum((t[tuple(assignment[i] for i in s)] for s, t in bucket), Q(0))
                best = score if best is None else max(best, score)
            table[values] = best
        factors.append((rest, table))
    answer = sum((t[()] for _, t in factors), Q(0))
    COUNTS['elimination_calls'] += 1
    COUNTS['elimination_bucket_assignments'] += stats['evaluated_bucket_assignments']
    return answer, dict(stats)


def neighbors(graphs, z):
    for i, v in enumerate(z):
        for w in graphs[i][v]:
            yield z[:i]+(w,)+z[i+1:]


def heap_capacity(graphs, values, x, y):
    best = {x: values[x]}
    queue = [(-values[x], x)]
    while queue:
        neg, u = heappop(queue)
        if -neg != best[u]:
            continue
        if u == y:
            return -neg
        for v in neighbors(graphs, u):
            candidate = min(-neg, values[v])
            if v not in best or candidate > best[v]:
                best[v] = candidate
                heappush(queue, (-candidate, v))
    return None


def threshold_capacity(graphs, values, x, y):
    """Independent oracle: direct threshold connectivity, no heap recurrence."""
    for threshold in sorted(set(values.values()), reverse=True):
        if min(values[x], values[y]) < threshold:
            continue
        reached, queue = {x}, deque([x])
        while queue:
            for v in neighbors(graphs, queue.popleft()):
                if values[v] >= threshold and v not in reached:
                    reached.add(v)
                    queue.append(v)
        if y in reached:
            return threshold
    return None


def coordinate_path(graphs, x, y):
    z, result = list(x), [x]
    for i, graph in enumerate(graphs):
        parent, queue = {z[i]: None}, deque([z[i]])
        while queue and y[i] not in parent:
            u = queue.popleft()
            for v in sorted(graph[u]):
                if v not in parent:
                    parent[v] = u
                    queue.append(v)
        if y[i] not in parent:
            return None
        route, v = [], y[i]
        while v is not None:
            route.append(v)
            v = parent[v]
        for v in route[-2::-1]:
            z[i] = v
            result.append(tuple(z))
    return result


def bounds(graphs, unary, pairs, x, y, blocks, verify_small=False):
    additive_capacity = additive.exact_product_bottleneck(graphs, unary, x, y)
    if additive_capacity is None:
        return {'status': 'baseline_disconnected'}
    m = min(field(unary, pairs, x), field(unary, pairs, y))
    zero = tuple(tuple(Q(0) for _ in f) for f in unary)
    i_max, _ = max_sum(zero, pairs)
    neg_i_min, _ = max_sum(zero, pairs, sign=-1)
    i_min = -neg_i_min
    global_low = additive_capacity+i_min
    global_high = min(m, additive_capacity+i_max)
    moves = additive.connection_witness(graphs, unary, x, y, additive_capacity)
    assert moves is not None
    z = list(x)
    additive_path = [tuple(z)]
    for i, v in moves:
        assert v in graphs[i][z[i]]
        z[i] = v
        additive_path.append(tuple(z))
    assert tuple(z) == y
    assert min(sum(unary[i][v] for i, v in enumerate(s)) for s in additive_path) >= additive_capacity
    direct_path = coordinate_path(graphs, x, y)
    assert direct_path is not None
    paths = [additive_path, direct_path]
    path_values = []
    for path in paths:
        assert path[0] == x and path[-1] == y
        for u, v in zip(path, path[1:]):
            changed = [i for i in range(len(graphs)) if u[i] != v[i]]
            assert len(changed) == 1 and v[changed[0]] in graphs[changed[0]][u[changed[0]]]
        path_values.append(min(field(unary, pairs, z) for z in path))
        COUNTS['witness_states_replayed'] += len(path)
    lower, upper = max(global_low, *path_values), global_high
    all_values = None
    if verify_small:
        all_values = {z: field(unary, pairs, z) for z in it.product(*(range(len(g)) for g in graphs))}
        i_values = [field(zero, pairs, z) for z in all_values]
        assert i_min == min(i_values) and i_max == max(i_values)
        a_values = {z: sum(unary[i][v] for i, v in enumerate(z)) for z in all_values}
        assert threshold_capacity(graphs, a_values, x, y) == additive_capacity
        truth = threshold_capacity(graphs, all_values, x, y)
        assert heap_capacity(graphs, all_values, x, y) == truth
        COUNTS['exact_capacity_checks'] += 1
    projected = []
    max_bucket_assignments = 0
    for block in blocks:
        envelope = {}
        for u in it.product(*(range(len(graphs[i])) for i in block)):
            envelope[u], stats = max_sum(unary, pairs, dict(zip(block, u)))
            max_bucket_assignments = max(max_bucket_assignments, stats['maximum_bucket_assignments'])
            if verify_small:
                brute = max(v for z, v in all_values.items() if all(z[i] == w for i, w in zip(block, u)))
                assert envelope[u] == brute
                COUNTS['envelope_entry_checks'] += 1
        subgraphs = tuple(graphs[i] for i in block)
        projected_cap = heap_capacity(subgraphs, envelope, tuple(x[i] for i in block), tuple(y[i] for i in block))
        assert projected_cap is not None
        upper = min(upper, projected_cap)
        projected.append({'block': block, 'capacity': projected_cap,
                          'envelope': [[u, value] for u, value in envelope.items()]})
        if verify_small:
            assert lower <= truth <= upper
            if len(block) == len(graphs):
                assert projected_cap == truth
            COUNTS['bound_inclusions_checked'] += 1
    assert global_low <= lower <= upper <= global_high
    result = {'status': 'bounded', 'capacity_bounds': [lower, upper], 'barrier_bounds': [m-upper, m-lower],
              'endpoint_minimum': m, 'additive_capacity': additive_capacity,
              'global_capacity_bounds': [global_low, global_high], 'global_barrier_bounds': [m-global_high, m-global_low],
              'interaction_range': [i_min, i_max], 'path_capacities': path_values,
              'paths': paths, 'projected': projected, 'largest_envelope_elimination_bucket_assignments': max_bucket_assignments}
    if verify_small:
        result['exact_capacity'] = truth
        result['exact_barrier'] = m-truth
    return result


def verify_suite():
    began = time.perf_counter()
    summaries = Counter()
    def check(graphs, unary, pairs, x, y, family):
        if time.perf_counter()-began > 180:
            raise TimeoutError('Bounded suite exceeded180seconds')
        blocks = [(i,) for i in range(len(graphs))]+list(it.combinations(range(len(graphs)), 2))
        r = bounds(graphs, unary, pairs, x, y, blocks, True)
        summaries[family] += 1
        summaries['exact_final_interval'] += r['capacity_bounds'][0] == r['capacity_bounds'][1]
        summaries['strict_interval_improvement'] += (r['capacity_bounds'] != r['global_capacity_bounds'])
    for u, h in it.product(it.product((-1, 1), repeat=4), it.product((-1, 0, 1), repeat=4)):
        check((K2, K2), (u[:2], u[2:]), {(0, 1): (h[:2], h[2:])}, (0, 0), (1, 1), 'Q2_exhaustive_fields')
    for coefficients in it.product((-1, 0, 1), repeat=6):
        unary = tuple((0, c) for c in coefficients[:3])
        pairs = {pair: ((0, 0), (0, c)) for pair, c in zip(it.combinations(range(3), 2), coefficients[3:])}
        check((K2,)*3, unary, pairs, (0,)*3, (1,)*3, 'Q3_exhaustive_coefficient_fields')
    for u, h in it.product(it.product((-1, 0, 1), repeat=5), (-3, 0, 3)):
        check((P3, K2), (u[:3], u[3:]), {(0, 1): ((0, 0), (0, h), (0, 0))}, (0, 0), (2, 0), 'P3K2_exhaustive_fields')
    rng = random.Random(271828)
    for _ in range(64):
        unary = tuple(tuple(Q(rng.randint(-2, 2), 2) for _ in range(n)) for n in (3, 2, 2))
        pairs = {(i, j): tuple(tuple(Q(rng.randint(-2, 2), 2) for _ in unary[j]) for _ in unary[i]) for i, j in it.combinations(range(3), 2)}
        check((P3, K2, K2), unary, pairs, (0, 0, 0), (2, 1, 1), 'rational_sampled_fields')
    assert [summaries[k] for k in ('Q2_exhaustive_fields', 'Q3_exhaustive_coefficient_fields', 'P3K2_exhaustive_fields', 'rational_sampled_fields')] == [1296, 729, 729, 64]
    return dict(summaries)


def named_examples():
    suppression = bounds((P3, K2), ((2, 0, 2), (0, 2)), {(0, 1): ((0, 0), (0, -3), (0, 0))}, (0, 0), (2, 0), [(0,)], True)
    assert suppression['barrier_bounds'] == [2, 2] and suppression['global_barrier_bounds'] == [0, 3]
    failure = bounds((K2, K2), ((0, 0), (0, 0)), {(0, 1): ((1, 0), (0, 1))}, (0, 0), (1, 1), [(0,), (1,)], True)
    assert failure['barrier_bounds'] == [0, 1] and failure['exact_barrier'] == 1
    d = 32
    large = bounds((P3,)+(K2,)*(d-1), ((2, 0, 2), (0, 2))+((0, 0),)*(d-2),
                   {(0, 1): ((0, 0), (0, -3), (0, 0))}, (0,)*d, (2,)+(0,)*(d-1), [(0,)], False)
    assert large['barrier_bounds'] == [2, 2]
    large['implicit_product_vertices'] = 3*2**31
    large['full_product_enumerated'] = False
    boundaries = []
    for values, x, y in [((Q(-3, 2), Q(-7, 3), Q(1, 2)), (0,), (2,)), ((1, 0, 2), (1,), (1,))]:
        boundaries.append(bounds((P3,), (values,), {}, x, y, [(0,)], True))
    disconnected = bounds((((), ()),), ((0, 1),), {}, (0,), (1,), [(0,)], False)
    assert disconnected['status'] == 'baseline_disconnected'
    return {'strict_improvement': suppression, 'singleton_projection_failure': failure,
            'large_non_enumerated': large, 'boundary_cases': boundaries, 'disconnected': disconnected}


def maxcut_checks():
    rows = []
    for n in range(1, 5):
        possible = list(it.combinations(range(n), 2))
        for included in it.product((0, 1), repeat=len(possible)):
            edges = [e for e, bit in zip(possible, included) if bit]
            m = len(edges)
            unary = ((m, 0, m),)+((0, 0),)*n
            pairs = {(i+1, j+1): ((0, 1), (1, 0)) for i, j in edges}
            graphs = (P3,)+(K2,)*n
            values = {z: field(unary, pairs, z) for z in it.product(range(3), *([range(2)]*n))}
            capacity = threshold_capacity(graphs, values, (0,)+(0,)*n, (2,)+(0,)*n)
            direct_cut = max(sum(z[i] != z[j] for i, j in edges) for z in it.product((0, 1), repeat=n))
            assert capacity == direct_cut
            rows.append({'n': n, 'edges': edges, 'capacity': capacity, 'direct_maxcut': direct_cut})
    assert len(rows) == 75
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('freeze', 'run'), required=True)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Assertions are required')
    if args.phase == 'freeze':
        if (HERE/'freeze.json').exists():
            raise FileExistsError('Do not overwrite a freeze')
        dump(HERE/'freeze.json', {'created_at': datetime.now(timezone.utc).isoformat(),
            'before_new_computations': True, 'input_sha256': {str(p.relative_to(ROOT)): sha(p) for p in INPUTS}})
        print('Frozen', sha(HERE/'freeze.json'))
        return
    frozen = json.loads((HERE/'freeze.json').read_text())
    for path, expected in frozen['input_sha256'].items():
        assert sha(ROOT/path) == expected
    if (HERE/'results.json').exists():
        raise FileExistsError('Do not overwrite results')
    start = time.perf_counter()
    results = {'named_examples': named_examples(), 'finite_suite': verify_suite(), 'maxcut_reduction_checks': maxcut_checks()}
    results['counts'] = dict(COUNTS)
    results['runtime_seconds'] = time.perf_counter()-start
    results['software'] = {'Python': platform.python_version()}
    results['status'] = 'passed_for_frozen_finite_inputs'
    results['proof_scope'] = 'Finite implementation corroboration; universal assertions rely on claim_and_proof.md'
    results['input_sha256'] = frozen['input_sha256']
    for path, expected in frozen['input_sha256'].items():
        assert sha(ROOT/path) == expected
    dump(HERE/'results.json', results)
    print(json.dumps({k: results[k] for k in ('status', 'finite_suite', 'counts', 'runtime_seconds')}, indent=2))


if __name__ == '__main__':
    main()
