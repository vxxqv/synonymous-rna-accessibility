# Structured interaction certificates for product accessibility

Base checkpoint: computational revision `e9846dca9f74b2c5c34e984eed970e996b9df2bf`. The additive implementation is `src/product_closure.py`, SHA-256 `96c6d35a6243dcf1ba0dbd08100d82dbbf553a583e3844e9ac6a31646d5ec63a`. This is one bounded A3 candidate, with a useful certificate, a failure example and a complexity obstruction. It is not a new biological result or an assertion of algorithmic priority.

## 1. Contract

Let `G_i=(V_i,E_i)` be explicit finite nonempty simple undirected graphs. Moves in their Cartesian product change one coordinate along an edge. Endpoints `x,y` are in the same baseline product component; otherwise capacity is nonfinite and no finite barrier assertion below applies. Restrict each factor to that baseline component. For a score field `F`, let

`C_F(x,y) = max_{P:x to y} min_{z in P} F(z)` and `B_F(x,y)=m_F-C_F(x,y)`, where `m_F=min(F(x),F(y))`.

The endpoints are included in each path minimum. Coincident endpoints have capacity their score and barrier zero. Scores are exact rational values for the implementation; the inequalities themselves hold for real values. The proposed input is

`F(z)=A(z)+I(z)`, `A(z)=sum_i f_i(z_i)`, `I(z)=sum_{ij in H} h_ij(z_i,z_j)`.

Each pair table is explicitly supplied and bounded because its domain is finite. This is a fixed known score model, not a calibrated simultaneous uncertainty region. No claim of polynomial exact interacting reachability follows from sparsity.

## 2. Projection and witness bound

Choose any nonempty family of nonempty coordinate blocks `S`. Write `G_S` for the product graph on the coordinates in a block and define the upper envelope

`U_S(u) = max_{z: z_S=u} F(z)`.

Choose any nonempty family of actual product paths `P_j` from `x` to `y`. Let `I_min <= I(z) <= I_max` throughout the baseline product. Define

`L = max(C_A + I_min, max_j min_{z in P_j} F(z))`,

`U = min(m_F, C_A + I_max, min_S C_{U_S}^{G_S}(x_S,y_S))`.

**Theorem.** `L <= C_F(x,y) <= U`, and therefore `m_F-U <= B_F(x,y) <= m_F-L`. The interval remains valid if an envelope is replaced by any certified pointwise upper bound, or the interaction extrema by valid outer bounds. Adding actual paths can only increase `L`; adding blocks can only decrease `U`. If the two bounds agree, they certify the exact capacity and barrier.

**Proof.** For every path `P`, its bottleneck under `F` lies between its bottleneck under `A` plus `I_min` and that bottleneck plus `I_max`. Maximizing over paths gives the two global bounds. An explicit path supplies a lower bound, and no path bottleneck exceeds `m_F`.

Project a product path onto coordinates `S`, deleting consecutive repeated projected states. This gives a walk from `x_S` to `y_S` in `G_S`, or the singleton walk if these endpoints agree. At every original path vertex, `F(z) <= U_S(z_S)`. Hence its bottleneck under `F` is no greater than the bottleneck of the projected walk under `U_S`. Deleting cycles cannot lower that latter bottleneck. Its value is at most the widest projected capacity. This holds for every original path and every block, proving the upper bound. Monotonicity under upper-envelope relaxation and under adding certificates is immediate. Subtracting from the exactly evaluated endpoint minimum gives the barrier interval. QED.

The projected route is an **upper certificate only**. Its maximizing outside coordinates may differ at successive projected vertices and need not be connected above the claimed level. The theorem neither selects compatible outside maximizers nor assumes that one projection represents a component.

## 3. Computing certificates without the full product

The existing additive algorithm supplies `C_A` and a path at that capacity in time polynomial in the explicit factor inputs and rational encoding. Its witness may not remain a good path after adding interactions, but it remains an actual baseline path and can be rescored. The implementation also uses one simple coordinatewise route, changing coordinates in fixed index order along lexicographic factor shortest paths. This second route has at most `sum_i(|V_i|-1)` moves. These fixed choices are certificates, not an optimization algorithm for interacting paths. Every route is replayed and rescored exactly.

Let `q=max(2,max_i |V_i|)`, let `r` be the number of pair tables, and supply an elimination order of induced width `w` for their interaction graph. Max-sum variable elimination computes `U_S(u)` by conditioning the coordinates in `S` to the specified values and eliminating all variables. Conditioning cannot increase the supplied order's width. The same method computes exact `I_min` and `I_max`; negating the interaction terms converts minimum into maximum. A feasible supplied order is sufficient; finding an optimal width is not assumed cheap.

For a block, write `Q_S=product_{i in S}|V_i|` and `E_S=sum_{i in S}|E_i| product_{j in S,j!=i}|V_j|`. Enumerating its envelope takes `Q_S` such elimination calls. A coarse arithmetic/comparison bound per call is `O((d+r) q^(w+1))` for bucket processing, plus input administration. The straightforward implementation additionally scans its active factor list on each eliminated variable, costing `O(d(d+r))`. A projected widest-path query costs `O((Q_S+E_S) log(max(2,Q_S)))`. Total time sums these expressions over the supplied blocks, adds two interaction-extremum calls, and adds additive-query and explicit-witness evaluation costs. Exact rational bit costs are additional. Intermediate arithmetic only sums or compares input rational values, so bit length remains polynomial in the explicit rational encoding, while the number of states can be exponential in `w` or block size.

Safe storage bounds are the explicit inputs plus `O((d+r) q^(w+1))` for this implementation's factor tables and `O(Q_S+E_S)` for the current projected graph. Blocks may be streamed. These are bounds in the supplied order and explicit block family, not a claim that bounded degree or a small number of pair tables implies bounded width. Taking `S` to be all coordinates makes the upper bound exact but enumerates the full product and is outside any fixed-small-block claim.

## 4. Strict improvement, including a large implicit product

Take `G_0=P3`, `f_0=(2,0,2)`, `G_1=K2`, `f_1=(0,2)`. The only interaction is `h_01(1,1)=-3`, zero elsewhere. The endpoints are `(0,0)` and `(2,0)`. The additive capacity is two and the additive barrier is zero. The actual endpoint minimum is two. Even the stronger endpoint-aware global interaction range `I in [-3,0]` gives capacity interval `[-1,2]` and barrier interval `[0,3]`; the generic `2 delta` barrier inequality alone gives `[0,6]`.

For block `{0}`, the envelope is `(4,0,4)`. Its projected capacity is zero. The coordinatewise path `(0,0),(1,0),(2,0)` also has bottleneck zero. Thus the new interval is the singleton `C_F=0`, `B_F=2`. The interaction removes the additive bypass. This is a strict improvement over both stated global bounds, not an artifact of comparing only against the weaker `2 delta` formula.

Appending any number of zero-scored binary factors with no new interactions preserves the same certificate. In particular, 32 factors have `3*2^31 = 6,442,450,944` product vertices. The selected envelope still has only three vertices, the interaction order has width one, and no full product needs to be constructed. The numerical verification explicitly records the largest elimination table and all actual witness moves.

## 5. Failure of exactness even with one interaction edge

On `K2 x K2`, take `A=0` and the one pair table with `F(0,0)=F(1,1)=1`, `F(0,1)=F(1,0)=0`. The endpoints are `(0,0)` and `(1,1)`. Both singleton envelopes are identically one, so every singleton projected query reports upper capacity one. Any actual route must visit an off-diagonal vertex, giving actual capacity zero and barrier one. Actual path certificates give lower capacity zero.

Thus singleton projections return barrier interval `[0,1]`, not the exact barrier. The error arises because the two compatible-looking projected steps need incompatible outside assignments. The interaction graph has treewidth one. Low interaction width makes envelope optimization cheap; it does not by itself make this projected reachability relaxation exact. Using the full two-coordinate block fixes this tiny case, but no claim that a fixed block size always suffices is made.

## 6. Sparse-interaction complexity obstruction

Let `H` be an unweighted graph with `n` vertices and `m` edges. Introduce binary coordinates `z_1,...,z_n`, with single-bit moves, and one switch coordinate `s` on `P3=(L,M,R)`. Set

`g(L)=g(R)=m`, `g(M)=0`, and `F(s,z)=g(s)+sum_{ij in E(H)} 1[z_i != z_j]`.

The endpoints are `(L,0^n)` and `(R,0^n)`, both with score `m`. Every route must pass through the middle switch state, so its bottleneck is at most `MaxCut(H)`. Conversely, at the left switch state every configuration has score at least `m`. Move to a maximum-cut assignment there, cross the switch, then return to `0^n` on the right. The resulting path has bottleneck exactly `MaxCut(H)`, because `MaxCut(H)<=m`. Therefore

`C_F = MaxCut(H)` and `B_F = m-MaxCut(H)`.

This is a polynomial many-one reduction for the decision `C_F >= K` from `MaxCut(H)>=K`, with explicit endpoints and rational/integer tables. It does not require the product graph to be supplied explicitly. The hard family itself has a polynomial witness: a cut assignment and the described switch route. We do **not** infer NP membership for arbitrary succinct interacting reachability from that fact.

The published MaxCut hardness on cubic graphs gives hardness even with `O(n)` pair tables, interaction degree at most three, factor domains at most three and individual interaction entries in `{0,1}`. The switch has no pair interactions. For any fixed positive rational `epsilon`, replace every cut contribution by `epsilon` and set `g(L)=g(R)=epsilon*m`. Capacity becomes `epsilon*MaxCut(H)`. One can instead set `epsilon=1/m` on nonempty cubic instances: every pair amplitude is at most `1/m` and the total interaction lies in `[0,1]`, yet exact capacity still recovers MaxCut by multiplication by `m`. Small bounded interactions alone do not make **exact** capacity tractable; an approximation guarantee must state its resolution. No inapproximability ratio for general capacity or barriers is asserted here.

The external leaf is cubic MaxCut hardness, stated in Alimonti and Kann's published abstract. The explicit reduction above is supplied in full. This is a transparent limitation argument, not a claim to the first complexity result for interacting energy landscapes.

## 7. Dependency and novelty boundary

| Obligation | Evidence | Status before fresh review |
|---|---|---|
| Projection sends a product path to a block walk | Direct Cartesian-edge argument in Section 2 | Proved, self-reviewed |
| Pointwise envelopes give capacity upper bounds | Max-min inequality and cycle deletion | Proved, elementary relaxation |
| Actual path gives capacity lower bound | Definition of widest capacity | Established principle |
| Exact interaction extrema/envelopes at supplied width | Max-sum elimination induction and primary Dechter precedent | Established algorithmic method |
| Polynomial additive witness | Existing audited additive source, with its stated witness qualification | Imported verified project dependency |
| Bounds strictly improve a stronger global perturbation bound | Explicit six-vertex example | Analytical calculation plus finite check |
| Cheap projections need not be exact | Explicit four-vertex example | Counterexample |
| Sparse bounded interactions can encode a hard capacity | Explicit switch reduction plus cubic MaxCut source | Proved conditional on established external theorem |

The generic ingredients are not new: bottleneck path certificates, state-space abstraction and variable elimination. The work supplies a concrete certified combination for the present product-input contract, an inspectable comparison with endpoint-aware perturbation bounds, and a direct sparse-interaction obstruction. No claim of a new general abstraction theorem, a novel variable-elimination algorithm, or first/fastest interacting-path method is justified. A complete novelty search for this exact combination has not been performed. A fresh reviewer should assess correctness and whether this scope is worth including, rather than infer importance from the large implicit vertex count.
