"""Independent finite max-min closure and exhaustive projection audit.

No creator solver is imported for the mathematical checks. A separately labelled
storage diagnostic invokes creator bounds only after all reference checks.
"""
from pathlib import Path
from fractions import Fraction as Q
import itertools as it
import json
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
vertices = lambda sizes: list(it.product(*(range(n) for n in sizes)))

def adjacent(x,y):
    return sum(a!=b for a,b in zip(x,y))==1 and sum(abs(a-b) for a,b in zip(x,y))==1

def score(unary,pairs,z):
    return sum(Q(f[z[i]]) for i,f in enumerate(unary))+sum(Q(t[z[i]][z[j]]) for (i,j),t in pairs.items())

def capacities(V,F):
    """Floyd closure over max/min semiring, different from creator heap/BFS."""
    C={(x,y):min(F[x],F[y]) if x==y or adjacent(x,y) else None for x in V for y in V}
    for k in V:
        for x in V:
            if C[x,k] is None: continue
            for y in V:
                if C[k,y] is None: continue
                a=min(C[x,k],C[k,y])
                if C[x,y] is None or a>C[x,y]:C[x,y]=a
    return C

def coordinate_path(x,y):
    z=list(x);P=[x]
    for i in range(len(x)):
        while z[i]!=y[i]:
            z[i]+=1 if y[i]>z[i] else -1
            P.append(tuple(z))
    return P

def check_field(unary,pairs):
    sizes=tuple(map(len,unary));V=vertices(sizes)
    F={z:score(unary,pairs,z) for z in V};A={z:score(unary,{},z) for z in V}
    CF,CA=capacities(V,F),capacities(V,A);I=[F[z]-A[z] for z in V]
    proj=[]
    for k in range(1,len(sizes)+1):
        for S in it.combinations(range(len(sizes)),k):
            W=vertices(tuple(sizes[i] for i in S))
            U={u:max(F[z] for z in V if tuple(z[i] for i in S)==u) for u in W}
            proj.append((S,capacities(W,U),capacities(W,{u:v+Q(1,3) for u,v in U.items()})))
    checks=0
    for x in V:
        for y in V:
            m=min(F[x],F[y]);lo=CA[x,y]+min(I);hi=min(m,CA[x,y]+max(I))
            assert lo<=CF[x,y]<=hi
            P=coordinate_path(x,y);lo=max(lo,min(F[z] for z in P))
            assert lo<=CF[x,y]
            for S,CP,relaxed in proj:
                a,b=tuple(x[i] for i in S),tuple(y[i] for i in S)
                assert CF[x,y]<=CP[a,b]<=relaxed[a,b]
                hi=min(hi,CP[a,b]);assert lo<=CF[x,y]<=hi
                if len(S)==len(sizes):assert CP[a,b]==CF[x,y]
                checks+=1
    return checks

def union_capacity(V,F,x,y):
    parent={}
    def find(a):
        while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
        return a
    for v in sorted(V,key=lambda z:F[z],reverse=True):
        parent[v]=v
        for u in list(parent):
            if adjacent(u,v):parent[find(u)]=find(v)
        if x in parent and y in parent and find(x)==find(y):return F[v]
    return None

out={'finite_projection_checks':0,'Q2_fields':0,'Q3_rational_fields':0}
for unary,h in it.product(it.product((-1,1),repeat=4),it.product((-1,0,1),repeat=4)):
    out['finite_projection_checks']+=check_field((unary[:2],unary[2:]),{(0,1):(h[:2],h[2:])})
    out['Q2_fields']+=1
for k in range(32):
    vals=[Q(((k+3)*(i+5)+i*i)%7-3,2+(i%3)) for i in range(18)]
    unary=tuple(tuple(vals[2*i:2*i+2]) for i in range(3))
    pairs={ij:tuple(tuple(vals[6+4*t+2*a+b] for b in range(2)) for a in range(2)) for t,ij in enumerate(it.combinations(range(3),2))}
    out['finite_projection_checks']+=check_field(unary,pairs);out['Q3_rational_fields']+=1

named=[]
for label,unary,pairs,x,y in [
 ('six_vertex',((2,0,2),(0,2)),{(0,1):((0,0),(0,-3),(0,0))},(0,0),(2,0)),
 ('four_vertex',((0,0),(0,0)),{(0,1):((1,0),(0,1))},(0,0),(1,1))]:
    V=vertices(tuple(map(len,unary)));F={z:score(unary,pairs,z) for z in V};A={z:score(unary,{},z) for z in V}
    truth=capacities(V,F)[x,y];ca=capacities(V,A)[x,y];m=min(F[x],F[y]);I=[F[z]-A[z] for z in V]
    envelope=[max(F[z] for z in V if z[0]==u) for u in range(len(unary[0]))]
    named.append({'name':label,'exact_capacity':truth,'barrier':m-truth,'additive_capacity':ca,
                  'global_capacity_interval':[ca+min(I),min(m,ca+max(I))],
                  'first_singleton_envelope':envelope,'coordinate_path_capacity':min(F[z] for z in coordinate_path(x,y))})
out['named_examples']=named

cuts=[]
graphs=[]
for n in range(1,5):
    E=list(it.combinations(range(n),2))
    graphs += [(n,[e for e,b in zip(E,mask) if b]) for mask in it.product((0,1),repeat=len(E))]
graphs += [(6,[(i,j) for i in range(3) for j in range(3,6)]),
           (6,[(0,1),(1,2),(0,2),(3,4),(4,5),(3,5),(0,3),(1,4),(2,5)])]
for n,E in graphs:
    m=len(E);assign=vertices((2,)*n);cut=lambda z:sum(z[i]!=z[j] for i,j in E)
    best=max(assign,key=cut);maximum=cut(best)
    for eps in set([Q(1),Q(1,7)]+([Q(1,m)] if m else [])):
        V=vertices((3,)+(2,)*n);F={z:eps*((m if z[0]!=1 else 0)+cut(z[1:])) for z in V}
        x,y=(0,)+(0,)*n,(2,)+(0,)*n;cap=union_capacity(V,F,x,y)
        P=coordinate_path(x,(0,)+best)+[(1,)+best,(2,)+best]+coordinate_path((2,)+best,y)[1:]
        assert cap==eps*maximum==min(F[z] for z in P)
        cuts.append({'n':n,'edges':E,'epsilon':eps,'capacity':cap,'maximum_cut':maximum})
out['maxcut_checks']=cuts

# Nontrivial coincident projections and inaccessible outside maximizers.
out['degenerate_one_factor_checks']=check_field(((Q(-3,2),Q(-7,3),Q(1,2)),),{})
out['inaccessible_maximizer']={'model':'P3 x two isolated vertices; x=(0,0),y=(2,0)',
 'accessible_scores':[2,0,2],'unreachable_outside_scores':[100,100,100],
 'true_capacity':0,'unrestricted_envelope_capacity':100,
 'restricted_envelope_capacity':0,'interpretation':'Unrestricted envelope remains valid but looser; exact baseline envelope requires restriction.'}

# Only this separate diagnostic invokes creator code, to inspect actual output
# storage and its unmatched baseline-component behavior, not to validate bounds.
spec=importlib.util.spec_from_file_location('creator_storage_diagnostic',D.parent/'verify_interactions.py')
creator=importlib.util.module_from_spec(spec);spec.loader.exec_module(creator)
out['creator_storage_diagnostic']=[]
for d in [8,16,32,64]:
    r=creator.bounds((creator.K2,)*d,((0,0),)*d,{},(0,)*d,(1,)*d,[(0,)],False)
    out['creator_storage_diagnostic'].append({'d':d,'path_lengths':list(map(len,r['paths'])),
      'stored_path_coordinate_entries':sum(len(z) for p in r['paths'] for z in p),
      'q':2,'w':0,'r':0,'projected_vertices':2})
disconnected=creator.bounds((creator.P3,((),())),((2,0,2),(0,100)),{},(0,0),(2,0),[(0,)],False)
assert disconnected['projected'][0]['capacity']==100
out['creator_unrestricted_disconnected_envelope']=disconnected['projected'][0]['capacity']
out['status']='reference checks pass; actual total-storage claim needs qualification'
target=D/'run/results.json';target.write_text(json.dumps(out,indent=2,default=str)+'\n')
print(json.dumps({'status':out['status'],'Q2_fields':out['Q2_fields'],'Q3_rational_fields':out['Q3_rational_fields'],
 'projection_checks':out['finite_projection_checks'],'scaled_MaxCut_checks':len(cuts),'storage':out['creator_storage_diagnostic']},indent=2))
