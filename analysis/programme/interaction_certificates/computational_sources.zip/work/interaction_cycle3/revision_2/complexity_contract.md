# Exact complexity contract for the preserved A3 implementation

This contract describes `../verify_interactions.py` at SHA256 `1ceeb89a3c40c2bae2c4995c8014c6163f51e8eff0be75de5c48ee988c5179e2`. No algorithm is changed in revision 2. Counts below distinguish mathematical arithmetic operations from coordinate and container bookkeeping. They are conservative bounds, not measured byte counts or fitted runtime estimates.

## Input domain and caller responsibilities

There are d >= 1 finite explicit simple undirected factors. Before claiming exact envelopes over the baseline component, the caller must find the component of x_i in every factor, verify that y_i belongs to it, and restrict and consistently reindex each graph, unary table, pair table and endpoint. Block coordinate identities remain unchanged under this within-factor restriction. The preserved `bounds()` function detects incompatible endpoints through the additive query, but does not trim other unreachable states automatically.

If the caller supplies untrimmed factors, maxima over their larger product are still pointwise upper bounds on the accessible domain and global interaction extrema remain valid outer bounds. The certificate inequalities remain sound, but those quantities cannot be labelled exact baseline-component extrema or envelopes. This qualification does not license treating an unreachable outside maximizer as an actual route.

Component discovery costs O(N+M), where N=sum_i n_i and M=sum_i m_i for vertex and edge counts. Copying restricted graphs and tables additionally scans their explicit input entries. No full Cartesian product is needed for this preprocessing.

## Size parameters and execution mode

Let q=max(2,max_i n_i), r be the number of supplied pair tables, and K=d+r. Zero-valued pair tables still belong to the implementation's structural interaction graph unless removed in a separate justified preprocessing step. This revision does not perform such removal.

The actual elimination order is 0,1,...,d-1. Let w be its induced width on the supplied pair-scope graph. The implementation has no order argument. A different order requires a consistent coordinate relabeling of factor graphs, unary tables, pair keys and entries, endpoints, and blocks. Reverse an asymmetric pair table's axes when required by the new key order. The chosen witness routes can depend on coordinate order, so relabeling need not preserve the particular reported lower bound even though exact model capacities and envelopes are invariant under the corresponding map. An optimal or merely small treewidth is not an upper bound on this implementation's natural-order width.

For each supplied block S_b, let b=|S_b|, Q_b=product_(i in S_b) n_i and E_b=sum_(i in S_b) m_i product_(j in S_b,j!=i) n_j. Let L be the total number of full path states retained across both witness paths, including their endpoints, and define R=sum_b (b+1)Q_b. R counts envelope score slots and their coordinate keys up to constants; it is summed across all blocks because the source retains them all.

The following bounds apply to `verify_small=False`. The `verify_small=True` audit branch explicitly enumerates all V=product_i n_i vertices and is accounted for separately below. Let I denote the explicit input storage, T_add the time of imported additive capacity and witness calls, and W_add their peak extra working storage. These additive costs retain their original rational bit and witness qualifications.

## One max-sum call

At elimination step i, let C_i be the collected bucket scope, t_i=|C_i| <= w+1, a_i=product_(j in C_i) |D_j|, and b_i the number of collected factors. Conditioning sets selected D_j to singletons, but the source still initially copies full original unary and pair tables. Let T0=sum_i n_i+sum_(ij) n_i n_j be their numeric entry count.

The exact bucket addition count is sum_i a_i b_i. The number of bucket maximum comparisons is sum_i [a_i - a_i/|D_i|]. Initial sign multiplication and final constant accumulation add O(T0+K+d) numeric operations. Every initial factor and each nonconstant factor produced by elimination is consumed at most once, so sum_i b_i <= 2d+r. Therefore a coarse rational arithmetic/comparison bound is O(K q^(w+1)). This counts table values, not arbitrary Python work.

Tuple-key construction and hashing inspect up to w+1 coordinate entries per factor lookup. Their coarse word-operation bound is O(K(w+1)q^(w+1)). The two active-list scans per step test membership in tuple scopes, contributing at most O(dK(w+1)) coordinate comparisons plus O(dK) list overhead. Scope union and sorting contribute at most O(K(w+1)+d(w+1)log(w+2)). The bound may be loose when variables are conditioned, which is acceptable. No unit-cost tuple membership or tuple hashing is assumed.

Peak elimination table storage is at most O(K q^(w+1)) rational value slots and O(K(w+1)q^(w+1)) coordinate/key/scope slots, including its initial copies. This is an elimination working-storage bound, not a total bound for `bounds()`.

## Complete certificate cost

There are exactly 2+sum_b Q_b max-sum calls for the two interaction extrema and all requested envelope entries. No envelope entries are discarded from the returned result.

Projected widest-path arithmetic/comparison work per block is O((Q_b+E_b)log(max(2,Q_b))). The graph is generated from factor adjacency rather than stored as one explicit edge list, but tuple construction, hashing and tied heap-key comparisons can inspect b coordinates. A conservative coordinate-word time bound is O((b+1)(Q_b+E_b)log(max(2,Q_b))), and peak additional heap/dictionary key storage is O((b+1)(Q_b+E_b)). The heap can retain stale entries, so O(Q_b) alone is not asserted for its peak storage.

Witness handling adds T_add plus O(dL) coordinate-copy and path-validation work. Rescoring the L states uses O(L(d+r)) rational additions/table accesses. The direct factor BFS route adds O(N+M log(max(2,q))) time, conservatively including the source's sorted neighbor lists. A compact additive move list is created, but `bounds()` then materializes the full d-coordinate tuples; it does not return only compact moves.

A conservative total storage bound, in coordinate/key or rational-value slots as appropriate, is:

`O(I + W_add + dL + K(w+1)q^(w+1) + R + max_b (b+1)(Q_b+E_b))`.

In particular, both `dL` and the sum R are required. The current implementation does not stream and discard previous block envelopes. A redesigned streaming interface could reduce retained output storage, but that is not the implementation reviewed or timed here. Shared Python references may save constants; no such sharing is needed for this upper bound.

For exact bit complexity, rational numerators and denominators of intermediate table values have polynomial bit length in the explicit rational input encoding: each value is a sum of selected original terms, with no factor duplicated in that sum. Multiply value-slot and arithmetic-operation estimates by the corresponding integer storage and arithmetic costs. Coordinate keys require enough bits to represent factor and state indices. This is not a strongly polynomial bound and does not remove exponential dependence on w or block size.

## Exhaustive verification branch

When `verify_small=True`, `bounds()` additionally materializes the whole product dictionary, a second additive-score dictionary and a list of interaction scores. This adds O((d+1)V) stored coordinate/value slots, plus O((d+1)(V+E_full)) for full-product heap and graph-search workspace, where E_full is the Cartesian edge count. Direct field evaluation costs O(V(d+r)). Threshold BFS over at most V distinct levels has a conservative coordinate-word time bound O(dV(V+E_full)), in addition to score sorting and heap verification. Exact envelope cross-checks also scan V full states for each requested entry, at cost O(sum_b Q_b V(b+1)). These checks are confined to declared small finite cases. They are excluded from any claim to avoid full-product enumeration.

## Explicit counterexample to the old total-storage reading

For d binary factors with zero scores, no interactions, x=0^d and y=1^d, each retained path has d+1 states. Thus L=2(d+1) and stored path coordinates number exactly 2d(d+1). Here q=2,w=0,r=0 and a singleton projection has two vertices. Elimination working tables can be linear in d while the actual materialized witness storage is quadratic. The revised total bound includes it.
