"""Retain the first diagnostic and generate a corrected separately named trace."""
from pathlib import Path
import hashlib

here = Path(__file__).resolve().parent
source = here/'targeted_regression.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '455b2036286cbd6772fd89883f51df3aff77031e4edac5325566cbd4c7593b7c'
text = source.read_text(encoding='utf-8')
text = text.replace('    buckets = []\n    def trace', '    buckets = []\n    scanned_variables = set()\n    def trace', 1)
text = text.replace("            if frame.f_lineno == scan_line:\n                var = loc['var']", "            if frame.f_lineno == scan_line and loc['var'] not in scanned_variables:\n                var = loc['var']\n                scanned_variables.add(var)", 1)
text = text.replace("    assert leaf_first['statistics']['maximum_bucket_scope'] == 2", "    assert leaf_first['statistics']['maximum_bucket_scope'] == 2\n    assert natural['accounting']['active_list_factor_visits'] == 62\n    assert natural['accounting']['active_list_coordinate_comparisons'] == 62\n    assert leaf_first['accounting']['active_list_factor_visits'] == 102\n    assert leaf_first['accounting']['active_list_coordinate_comparisons'] == 122", 1)
text = text.replace("'protocol.json', 'make_revision.py', 'targeted_regression.py')", "'protocol.json', 'make_revision.py', 'targeted_regression.py',\n                                  'targeted_regression_v2.py', 'make_trace_correction.py', 'trace_erratum.md')", 1)
text = text.replace("HERE/'freeze.json', HERE/'results.json'", "HERE/'freeze_v2.json', HERE/'results_v2.json'", 1)
text = text.replace("dump(HERE/'manifest.json', manifest)", "dump(HERE/'manifest_v2.json', manifest)", 1)
target = here/'targeted_regression_v2.py'
if target.exists():
    raise FileExistsError('Do not overwrite corrected diagnostic')
target.write_text(text, encoding='utf-8')
print(target)
