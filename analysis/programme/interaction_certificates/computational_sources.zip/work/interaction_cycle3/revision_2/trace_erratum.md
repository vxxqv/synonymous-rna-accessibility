# Initial diagnostic trace erratum

The initial `results.json` correctly records the mathematical, storage, envelope and order checks. Its active-list visit and coordinate-comparison counters are inflated. Python 3.12 emits repeated line events within inlined list comprehensions, so the first tracer counted the same elimination step more than once. This diagnostic bug is confined to those counters and did not modify the original A3 source or any mathematical outcomes.

The initial source, freeze, result and manifest remain unchanged. The final corrected accounting evidence is `targeted_regression_v2.py`, `freeze_v2.json`, `results_v2.json` and `manifest_v2.json`. The corrected tracer counts each eliminated variable once and checks the star-example totals against hand-derived counts: natural order62 factor visits and62 coordinate comparisons; relabeled leaf-first102 factor visits and122 coordinate comparisons. Table additions and key-coordinate counts were unaffected.

Use the corrected receipt for scan-cost diagnostics. This erratum supersedes any interpretation of the initial receipt as validating those two counters. It does not change the corrected proof or complexity contract.
