"""Produce a separate corrected proof, preserving all original inputs."""
from pathlib import Path
import hashlib

HERE = Path(__file__).resolve().parent
original = HERE.parent/'claim_and_proof.md'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '5997617d4cde32104fe9cd8ba631fd58719e07bdcbf6b7f4d49986aa811412a4'
text = original.read_text(encoding='utf-8')
text = text.replace('# Structured interaction certificates for product accessibility',
                    '# Structured interaction certificates for product accessibility: revision 2', 1)
text = text.replace('Restrict each factor to that baseline component.',
                    'The mathematical domain is the product of those baseline components. The caller must explicitly restrict and reindex the factors, unary tables, pair tables and endpoints before claiming exact envelopes on that domain. The preserved implementation does not perform this trimming automatically. Untrimmed maxima remain valid outer bounds, but are not exact baseline-component envelopes.')
start = text.index('## 3. Computing certificates without the full product')
end = text.index('## 4. Strict improvement', start)
section = '''## 3. Computing certificates without the full product

The existing additive algorithm supplies C_A and an actual route at that capacity. The route remains a valid baseline route after adding interactions and can be rescored. The implementation also uses a fixed coordinatewise factor-BFS route. These are certificates, not an optimization algorithm for interacting paths. It stores both routes as full coordinate tuples.

Exact max-sum variable elimination evaluates the projected envelopes and interaction extrema. The preserved implementation eliminates variables in natural order 0,1,...,d-1. Width w refers to that actual order, not optimal treewidth. A different order requires a consistent input relabeling, including asymmetric pair-table axes, endpoints and blocks. Conditioning cannot enlarge the order's structural scopes, although initial table copies still use the full supplied table domains.

For d factors and r pair tables, K=d+r and q=max(2,max_i|V_i|), one call uses O(K q^(w+1)) rational table operations. This is not a bound on all Python work: tuple keys, scope membership and scope construction have explicit coordinate-length costs. Let L be the total stored path-state count, Q_b and E_b the block product's vertex and edge counts, and R=sum_b(|S_b|+1)Q_b. Total storage includes O(dL) materialized witness coordinates and all R retained envelope slots, in addition to elimination workspace, projected-query workspace, explicit inputs and the imported additive workspace. Previously completed block outputs are retained; the current code does not stream and discard them.

The standalone `complexity_contract.md` in this revision specifies complete time and storage accounting, rational bit qualifications, caller preprocessing and the optional exhaustive verification branch. It is part of this claim's computational contract. In particular, `verify_small=True` explicitly enumerates the Cartesian product and is excluded from any nonenumeration claim. A small interaction degree does not imply small natural-order width, and a small width does not make the projection relaxation exact. Taking a full-coordinate block enumerates the full product.

'''
text = text[:start]+section+text[end:]
text = text.replace('Status before fresh review', 'Status after separate review and accounting correction')
text = text.replace('Proved, self-reviewed', 'Direct proof checked by separately authored review')
text = text.replace('Exact interaction extrema/envelopes at supplied width', 'Exact interaction extrema/envelopes at actual natural-order width')
text = text.replace('A fresh reviewer should assess correctness and whether this scope is worth including, rather than infer importance from the large implicit vertex count.',
                    'A separately authored reviewer found the mathematical certificates and examples sound but required the storage, order and bookkeeping corrections now stated. Priority remains unresolved. The large implicit vertex count does not establish general algorithmic importance.')
text += '''
## 8. Revision provenance and finite evidence limits

This revision changes the computational accounting and caller contract only. The original proof, code, freeze and results are preserved. See `correction_ledger.md` and the separately authored review at `../independent_review/review.md`, SHA256 `d799a664503fdbb50b2332aab9891a9221f05bdbb23cefde7acc6397187c71ca`.

The original creator suite has2818 parameter inputs in its stated families. Its previously recorded outcomes are unchanged. The separate review's1296 Q2 parameter inputs have929 distinct score fields; its32 deterministic rational Q3 inputs have only seven distinct score fields because the generator has period seven. These counts describe that review, not additional independent landscapes. Finite agreement is corroboration, not a universal proof.

The cubic-MaxCut hardness conclusion remains conditional on the established Alimonti-Kann theorem. The reviewer inspected primary statements but did not re-prove the external theorem. Dechter's recovered earlier primary paper supports the established elimination method; the2018 abstraction source concerns additive path costs and is not cited as the identical max-min theorem. Original source-access limitations and unresolved priority are retained in the original primary-prior record and the separate review. No new generic method or biological result is claimed.
'''
text = text.replace('has2818', 'has 2818').replace("review's1296", "review's 1296").replace('have929', 'have 929').replace('its32', 'its 32').replace('the2018', 'the 2018')
target = HERE/'claim_and_proof.md'
if target.exists():
    raise FileExistsError('Do not overwrite a completed revision')
target.write_text(text, encoding='utf-8')
print(target)
