# Structured interaction certificates for product accessibility: revision 2

Base checkpoint: computational revision `e9846dca9f74b2c5c34e984eed970e996b9df2bf`. The additive implementation is `src/product_closure.py`, SHA-256 `96c6d35a6243dcf1ba0dbd08100d82dbbf553a583e3844e9ac6a31646d5ec63a`. This is one bounded A3 candidate, with a useful certificate, a failure example and a complexity obstruction. It is not a new biological result or an assertion of algorithmic priority.

## 1. Contract

Let `G_i=(V_i,E_i)` be explicit finite nonempty simple undirected graphs. Moves in their Cartesian product change one coordinate along an edge. Endpoints `x,y` are in the same baseline product component; otherwise capacity is nonfinite and no finite barrier assertion below applies. The mathematical domain is the product of those baseline components. The caller must explicitly restrict and reindex the factors, unary tables, pair tables and endpoints before claiming exact envelopes on that domain. The preserved implementation does not perform this trimming automatically. Untrimmed maxima remain valid outer bounds, but are not exact baseline-component envelopes. For a score field `F`, let

`C_F(x,y) = max_{P:x to y} min_{z in P} F(z)` and `B_F(x,y)=m_F-C_F(x,y)`, where `m_F=min(F(x),F(y))`.

The endpoints are included in each path minimum. Coincident endpoints have capacity their score and barrier zero. Scores are exact rational values for the implementation; the inequalities themselves hold for real values. The proposed input is

`F(z)=A(z)+I(z)`, `A(z)=sum_i f_i(z_i)`, `I(z)=sum_{ij in H} h_ij(z_i,z_j)`.

Each pair table is explicitly supplied and bounded because its domain is finite. This is a fixed known score model, not a calibrated simultaneous uncertainty region. No claim of polynomial exact interacting reachability follows from sparsity.

## 2. Projection and witness bound

Choose any nonempty family of nonempty coordinate blocks `S`. Write `G_S` for the product graph on the coordinates in a block and define the upper envelope

`U_S(u) = max_{z: z_S=u} F(z)`.

Choose any nonempty family of actual product paths `P_j` from `x` to `y`. Let `I_min <= I(z) <= I_max` throughout the baseline product. Define

`L = max(C_A + I_min, max_j min_{z in P_j} F(z))`,

`U = min(m_F, C_A + I_max, min_S C_{U_S}^{G_S}(x_S,y_S))`.

**Theorem.** `L <= C_F(x,y) <= U`, and therefore `m_F-U <= B_F(x,y) <= m_F-L`. The interval remains valid if an envelope is replaced by any certified pointwise upper bound, or the interaction extrema by valid outer bounds. Adding actual paths can only increase `L`; adding blocks can only decrease `U`. If the two bounds agree, they certify the exact capacity and barrier.

**Proof.** For every path `P`, its bottleneck under `F` lies between its bottleneck under `A` plus `I_min` and that bottleneck plus `I_max`. Maximizing over paths gives the two global bounds. An explicit path supplies a lower bound, and no path bottleneck exceeds `m_F`.

Project a product path onto coordinates `S`, deleting consecutive repeated projected states. This gives a walk from `x_S` to `y_S` in `G_S`, or the singleton walk if these endpoints agree. At every original path vertex, `F(z) <= U_S(z_S)`. Hence its bottleneck under `F` is no greater than the bottleneck of the projected walk under `U_S`. Deleting cycles cannot lower that latter bottleneck. Its value is at most the widest projected capacity. This holds for every original path and every block, proving the upper bound. Monotonicity under upper-envelope relaxation and under adding certificates is immediate. Subtracting from the exactly evaluated endpoint minimum gives the barrier interval. QED.

The projected route is an **upper certificate only**. Its maximizing outside coordinates may differ at successive projected vertices and need not be connected above the claimed level. The theorem neither selects compatible outside maximizers nor assumes that one projection represents a component.

## 3. Computing certificates without the full product

The existing additive algorithm supplies C_A and an actual route at that capacity. The route remains a valid baseline route after adding interactions and can be rescored. The implementation also uses a fixed coordinatewise factor-BFS route. These are certificates, not an optimization algorithm for interacting paths. It stores both routes as full coordinate tuples.

Exact max-sum variable elimination evaluates the projected envelopes and interaction extrema. The preserved implementation eliminates variables in natural order 0,1,...,d-1. Width w refers to that actual order, not optimal treewidth. A different order requires a consistent input relabeling, including asymmetric pair-table axes, endpoints and blocks. Conditioning cannot enlarge the order's structural scopes, although initial table copies still use the full supplied table domains.

For d factors and r pair tables, K=d+r and q=max(2,max_i|V_i|), one call uses O(K q^(w+1)) rational table operations. This is not a bound on all Python work: tuple keys, scope membership and scope construction have explicit coordinate-length costs. Let L be the total stored path-state count, Q_b and E_b the block product's vertex and edge counts, and R=sum_b(|S_b|+1)Q_b. Total storage includes O(dL) materialized witness coordinates and all R retained envelope slots, in addition to elimination workspace, projected-query workspace, explicit inputs and the imported additive workspace. Previously completed block outputs are retained; the current code does not stream and discard them.

The standalone `complexity_contract.md` in this revision specifies complete time and storage accounting, rational bit qualifications, caller preprocessing and the optional exhaustive verification branch. It is part of this claim's computational contract. In particular, `verify_small=True` explicitly enumerates the Cartesian product and is excluded from any nonenumeration claim. A small interaction degree does not imply small natural-order width, and a small width does not make the projection relaxation exact. Taking a full-coordinate block enumerates the full product.

## 4. Strict improvement, including a large implicit product

Take `G_0=P3`, `f_0=(2,0,2)`, `G_1=K2`, `f_1=(0,2)`. The only interaction is `h_01(1,1)=-3`, zero elsewhere. The endpoints are `(0,0)` and `(2,0)`. The additive capacity is two and the additive barrier is zero. The actual endpoint minimum is two. Even the stronger endpoint-aware global interaction range `I in [-3,0]` gives capacity interval `[-1,2]` and barrier interval `[0,3]`; the generic `2 delta` barrier inequality alone gives `[0,6]`.

For block `{0}`, the envelope is `(4,0,4)`. Its projected capacity is zero. The coordinatewise path `(0,0),(1,0),(2,0)` also has bottleneck zero. Thus the new interval is the singleton `C_F=0`, `B_F=2`. The interaction removes the additive bypass. This is a strict improvement over both stated global bounds, not an artifact of comparing only against the weaker `2 delta` formula.

Appending any number of zero-scored binary factors with no new interactions preserves the same certificate. In particular, 32 factors have `3*2^31 = 6,442,450,944` product vertices. The selected envelope still has only three vertices, the interaction order has width one, and no full product needs to be constructed. The numerical verification explicitly records the largest elimination table and all actual witness moves.

## 5. Failure of exactness even with one interaction edge

On `K2 x K2`, take `A=0` and the one pair table with `F(0,0)=F(1,1)=1`, `F(0,1)=F(1,0)=0`. The endpoints are `(0,0)` and `(1,1)`. Both singleton envelopes are identically one, so every singleton projected query reports upper capacity one. Any actual route must visit an off-diagonal vertex, giving actual capacity zero and barrier one. Actual path certificates give lower capacity zero.

Thus singleton projections return barrier interval `[0,1]`, not the exact barrier. The error arises because the two compatible-looking projected steps need incompatible outside assignments. The interaction graph has treewidth one. Low interaction width makes envelope optimization cheap; it does not by itself make this projected reachability relaxation exact. Using the full two-coordinate block fixes this tiny case, but no claim that a fixed block size always suffices is made.

## 6. Sparse-interaction complexity obstruction

Let `H` be an unweighted graph with `n` vertices and `m` edges. Introduce binary coordinates `z_1,...,z_n`, with single-bit moves, and one switch coordinate `s` on `P3=(L,M,R)`. Set

`g(L)=g(R)=m`, `g(M)=0`, and `F(s,z)=g(s)+sum_{ij in E(H)} 1[z_i != z_j]`.

The endpoints are `(L,0^n)` and `(R,0^n)`, both with score `m`. Every route must pass through the middle switch state, so its bottleneck is at most `MaxCut(H)`. Conversely, at the left switch state every configuration has score at least `m`. Move to a maximum-cut assignment there, cross the switch, then return to `0^n` on the right. The resulting path has bottleneck exactly `MaxCut(H)`, because `MaxCut(H)<=m`. Therefore

`C_F = MaxCut(H)` and `B_F = m-MaxCut(H)`.

This is a polynomial many-one reduction for the decision `C_F >= K` from `MaxCut(H)>=K`, with explicit endpoints and rational/integer tables. It does not require the product graph to be supplied explicitly. The hard family itself has a polynomial witness: a cut assignment and the described switch route. We do **not** infer NP membership for arbitrary succinct interacting reachability from that fact.

The published MaxCut hardness on cubic graphs gives hardness even with `O(n)` pair tables, interaction degree at most three, factor domains at most three and individual interaction entries in `{0,1}`. The switch has no pair interactions. For any fixed positive rational `epsilon`, replace every cut contribution by `epsilon` and set `g(L)=g(R)=epsilon*m`. Capacity becomes `epsilon*MaxCut(H)`. One can instead set `epsilon=1/m` on nonempty cubic instances: every pair amplitude is at most `1/m` and the total interaction lies in `[0,1]`, yet exact capacity still recovers MaxCut by multiplication by `m`. Small bounded interactions alone do not make **exact** capacity tractable; an approximation guarantee must state its resolution. No inapproximability ratio for general capacity or barriers is asserted here.

The external leaf is cubic MaxCut hardness, stated in Alimonti and Kann's published abstract. The explicit reduction above is supplied in full. This is a transparent limitation argument, not a claim to the first complexity result for interacting energy landscapes.

## 7. Dependency and novelty boundary

| Obligation | Evidence | Status after separate review and accounting correction |
|---|---|---|
| Projection sends a product path to a block walk | Direct Cartesian-edge argument in Section 2 | Direct proof checked by separately authored review |
| Pointwise envelopes give capacity upper bounds | Max-min inequality and cycle deletion | Proved, elementary relaxation |
| Actual path gives capacity lower bound | Definition of widest capacity | Established principle |
| Exact interaction extrema/envelopes at actual natural-order width | Max-sum elimination induction and primary Dechter precedent | Established algorithmic method |
| Polynomial additive witness | Existing audited additive source, with its stated witness qualification | Imported verified project dependency |
| Bounds strictly improve a stronger global perturbation bound | Explicit six-vertex example | Analytical calculation plus finite check |
| Cheap projections need not be exact | Explicit four-vertex example | Counterexample |
| Sparse bounded interactions can encode a hard capacity | Explicit switch reduction plus cubic MaxCut source | Proved conditional on established external theorem |

The generic ingredients are not new: bottleneck path certificates, state-space abstraction and variable elimination. The work supplies a concrete certified combination for the present product-input contract, an inspectable comparison with endpoint-aware perturbation bounds, and a direct sparse-interaction obstruction. No claim of a new general abstraction theorem, a novel variable-elimination algorithm, or first/fastest interacting-path method is justified. A complete novelty search for this exact combination has not been performed. A separately authored reviewer found the mathematical certificates and examples sound but required the storage, order and bookkeeping corrections now stated. Priority remains unresolved. The large implicit vertex count does not establish general algorithmic importance.

## 8. Revision provenance and finite evidence limits

This revision changes the computational accounting and caller contract only. The original proof, code, freeze and results are preserved. See `correction_ledger.md` and the separately authored review at `../independent_review/review.md`, SHA256 `d799a664503fdbb50b2332aab9891a9221f05bdbb23cefde7acc6397187c71ca`.

The original creator suite has 2818 parameter inputs in its stated families. Its previously recorded outcomes are unchanged. The separate review's 1296 Q2 parameter inputs have 929 distinct score fields; its 32 deterministic rational Q3 inputs have only seven distinct score fields because the generator has period seven. These counts describe that review, not additional independent landscapes. Finite agreement is corroboration, not a universal proof.

The cubic-MaxCut hardness conclusion remains conditional on the established Alimonti-Kann theorem. The reviewer inspected primary statements but did not re-prove the external theorem. Dechter's recovered earlier primary paper supports the established elimination method; the 2018 abstraction source concerns additive path costs and is not cited as the identical max-min theorem. Original source-access limitations and unresolved priority are retained in the original primary-prior record and the separate review. No new generic method or biological result is claimed.
