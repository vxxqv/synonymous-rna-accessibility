# A3 revision 2 handoff

The corrected claim is `claim_and_proof.md`, with its full accounting in `complexity_contract.md` and review-objection mapping in `correction_ledger.md`. The underlying algorithm and all original A3 sources, freezes and results are unchanged.

The revision resolves the review's qualifications:

* Total storage includes full-coordinate witnesses O(dL), every retained block envelope, projected heap keys, explicit inputs and imported additive workspace.
* Width refers to actual natural elimination order. Other orders require consistent input relabeling, including pair-table transposition when needed.
* Rational table operations, tuple/key costs and active-list scope scans are separated.
* Baseline-component restriction is explicit caller preprocessing. Untrimmed quantities remain valid outer bounds but cannot be called exact baseline-component envelopes.
* The optional exhaustive finite-verification branch and its product-sized costs are explicit.
* The separate review's duplicate-field counts and conditional prior claims are retained.

Final evidence is `freeze_v2.json`, `targeted_regression_v2.py`, `results_v2.json` and `manifest_v2.json`. The corrected targeted run passed in 0.0444 seconds, and the Mathbox v2 validator verified its input/output hashes and completed status.

| Check | Exact result |
| --- | --- |
| Full witness coordinate storage for d=8,16,32,64 | 144,544,2112,8320, exactly 2d(d+1) |
| Retained singleton/pair outputs for four binary factors | 32 score entries plus 56 key coordinates, across ten blocks |
| Six-variable star before/after consistent leaf-first relabeling | Induced widths five/one; largest bucket assignments 64/4; exact maximum 15 in both |
| Actual bucket additions versus key-coordinate visits | Natural 508/1024; relabeled 52/72 |
| Actual active-list factor visits versus coordinate comparisons | Natural 62/62; relabeled 102/122 |
| Baseline restriction | Raw projected capacity 100, component-restricted 0, both final capacity intervals [0,0] |
| Strict improvement and exactness failure | Original barrier results [2,2] and [0,1] preserved |
| Separate-review distinct field counts | 929 of 1296 Q2 inputs; seven of 32 Q3 inputs |

The initial diagnostic had a Python 3.12 tracing overcount for active-list visits. It is preserved and explicitly superseded for those counters by `trace_erratum.md`. Corrected versus initial receipts differ only in four affected counters and runtime. No mathematical result or algorithm changed.

Final SHA256 values:

```text
claim_and_proof.md       3ab20e5d1a792676105af4170c35483f729fbef41576ddd470ac6d4a4c53390b
complexity_contract.md  285270290b389cf1e0766d66a510948ac161edf98111de3d951b5cab49ea59f2
targeted_regression_v2.py 6c70d1418eebac4492515219932a7dc2a95d9f4d5180f88c4e3db225191ec67b
results_v2.json          a25d37649e209b0ac85f2c25645d63332529e335ed0f1d93f56b81bb2cb7bcc7
manifest_v2.json         0bfbc5dcc39f742022c049568e7b451f582d50965a952ff54f62fe6a4939e85a
```

The mathematical certificates remain an explicit combination of established ideas, with a strict improvement example and a relaxation failure. Cubic-MaxCut hardness is a named external theorem, not re-proved here. No new general method, hard-instance performance guarantee or biological finding is asserted. This bounded revision is complete; no repository or manuscript files were edited.
