# A3 revision 2 correction ledger

Original proof, code, freeze and numerical receipts remain unchanged. This is a documentation and accounting correction, not a new computational method or a retuned benchmark.

| Review observation | Revision 2 resolution | Targeted evidence |
| --- | --- | --- |
| Original total-storage reading omits full-coordinate paths | Total storage includes O(dL), with L defined as all retained path states | Reproduce zero-field binary products at d=8,16,32,64 and count coordinates exactly |
| All block envelopes remain in returned `projected` output | Total storage includes R=sum_b(|S_b|+1)Q_b, plus current projected workspace | Four-factor example retains all singleton and pair envelopes; count entries and key coordinates |
| `max_sum` uses `range(d)`, not an arbitrary supplied order | Width means the actual natural order; another order requires complete relabeling | Six-factor star has natural width five; consistent leaf-first relabeling gives width one and the same exact table maximum |
| Table operations do not include scope/key bookkeeping | Separate arithmetic, tuple-key operations, list membership, scope sorting and coordinate storage | Trace the unchanged function's real bucket scopes to count additions, key visits and membership comparisons |
| Baseline-component restriction is not automatic | State component restriction as caller preprocessing and label untrimmed results as valid outer bounds | Disconnected outside factor gives unrestricted envelope100 but restricted envelope0 |
| Optional finite checker enumerates the product | Explicit `verify_small=True` time and storage paragraph | Keep tiny named mathematical checks clearly separate from nonenumerating accounting tests |
| Review's32 rational Q3 inputs contain only seven distinct fields | Preserve and state that exact coverage limit | Reconstruct the documented deterministic generator's score vectors and count seven distinct fields; no rerun of the large review suite |
| Review's1296 Q2 parameter inputs contain929 distinct score fields | Retain both counts and their distinction | Reconstruct parameter-to-score vectors only, without a new graph analysis |
| Cubic MaxCut hardness source was not re-proved | Keep hardness conditional on the named established theorem and preserve source-access limits | Citation/proof dependency statement, not a new numerical check |
| Projection and elimination tools are established prior | No new general abstraction or elimination novelty claim | Revised dependency table and inherited primary-prior record |

No result is discarded. The strict six-vertex improvement, four-vertex exactness failure, bounded-width envelope qualification and explicit switch reduction are unchanged. The largest implicit product remains an input-representation example with explicit witness/output costs, not a general scalability benchmark.
