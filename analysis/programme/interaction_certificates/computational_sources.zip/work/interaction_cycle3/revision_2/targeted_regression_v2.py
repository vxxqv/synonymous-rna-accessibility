"""Accounting diagnostics of held source, plus independent tiny field evaluations."""
from collections import Counter, deque
from datetime import datetime, timezone
from fractions import Fraction as Q
from pathlib import Path
from time import perf_counter
import hashlib
import importlib.util
import inspect
import itertools as it
import json
import platform
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ORIGINAL = HERE.parent
SOURCE = ORIGINAL/'verify_interactions.py'
REVIEW = ORIGINAL/'independent_review/review.md'
CODE_SHA = '1ceeb89a3c40c2bae2c4995c8014c6163f51e8eff0be75de5c48ee988c5179e2'
REVIEW_SHA = 'd799a664503fdbb50b2332aab9891a9221f05bdbb23cefde7acc6397187c71ca'
hash_file = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def dump(p, value):
    p.write_text(json.dumps(value, indent=2, default=str)+'\n', encoding='utf-8')


def direct_value(unary, pairs, state):
    return sum((Q(row[state[i]]) for i, row in enumerate(unary)), Q(0))+sum(
        (Q(table[state[i]][state[j]]) for (i, j), table in pairs.items()), Q(0))


def traced_elimination(module, unary, pairs):
    lines, first = inspect.getsourcelines(module.max_sum)
    scan_line = first+next(i for i, line in enumerate(lines) if line.strip().startswith('bucket ='))
    table_line = first+next(i for i, line in enumerate(lines) if line.strip() == 'table = {}')
    total = Counter()
    buckets = []
    scanned_variables = set()
    def trace(frame, event, arg):
        if frame.f_code is module.max_sum.__code__ and event == 'line':
            loc = frame.f_locals
            if frame.f_lineno == scan_line and loc['var'] not in scanned_variables:
                var = loc['var']
                scanned_variables.add(var)
                for scope, _ in loc['factors']:
                    # Both list comprehensions test membership in the same scopes.
                    total['active_list_factor_visits'] += 2
                    for coordinate in scope:
                        total['active_list_coordinate_comparisons'] += 2
                        if coordinate == var:
                            break
            if frame.f_lineno == table_line:
                scope, bucket, domains = loc['scope'], loc['bucket'], loc['domains']
                assignments = 1
                for i in scope:
                    assignments *= len(domains[i])
                additions = assignments*len(bucket)
                key_visits = assignments*sum(len(s) for s, _ in bucket)
                total['bucket_value_additions'] += additions
                total['bucket_key_coordinate_visits'] += key_visits
                total['bucket_maximum_comparisons'] += assignments-assignments//len(domains[loc['var']])
                buckets.append({'variable':loc['var'], 'scope':scope, 'assignments':assignments,
                                'factors':len(bucket), 'key_coordinate_visits':key_visits})
        return trace
    previous = sys.gettrace()
    try:
        sys.settrace(trace)
        value, stats = module.max_sum(unary, pairs)
    finally:
        sys.settrace(previous)
    assert max(len(b['scope']) for b in buckets) == stats['maximum_bucket_scope']
    assert sum(b['assignments'] for b in buckets) == stats['evaluated_bucket_assignments']
    return {'value':value, 'statistics':stats, 'accounting':dict(total), 'buckets':buckets}


def relabel(unary, pairs, new_to_old):
    old_to_new = {old:new for new, old in enumerate(new_to_old)}
    new_pairs = {}
    for (i, j), table in pairs.items():
        a, b = old_to_new[i], old_to_new[j]
        if a < b:
            new_pairs[a, b] = table
        else:
            new_pairs[b, a] = tuple(tuple(table[u][v] for u in range(len(table)))
                                    for v in range(len(table[0])))
    return tuple(unary[old] for old in new_to_old), new_pairs


def restrict_components(graphs, unary, pairs, x, y):
    """Caller-only demonstration. The held implementation does not invoke this."""
    domains = []
    for graph, start, target in zip(graphs, x, y):
        seen, queue = {start}, deque([start])
        while queue:
            u = queue.popleft()
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    queue.append(v)
        if target not in seen:
            raise ValueError('Endpoints in different baseline components')
        domains.append(tuple(sorted(seen)))
    inverse = [{v:j for j, v in enumerate(domain)} for domain in domains]
    new_graphs = tuple(tuple(tuple(inverse[i][w] for w in graphs[i][v] if w in inverse[i]) for v in domain)
                       for i, domain in enumerate(domains))
    new_unary = tuple(tuple(unary[i][v] for v in domain) for i, domain in enumerate(domains))
    new_pairs = {(i, j):tuple(tuple(table[u][v] for v in domains[j]) for u in domains[i])
                 for (i, j), table in pairs.items()}
    return new_graphs, new_unary, new_pairs, tuple(inverse[i][v] for i, v in enumerate(x)), tuple(inverse[i][v] for i, v in enumerate(y))


def suite(module):
    storage = []
    for d in (8, 16, 32, 64):
        result = module.bounds((module.K2,)*d, ((0, 0),)*d, {}, (0,)*d, (1,)*d, [(0,)], False)
        lengths = [len(path) for path in result['paths']]
        coordinates = sum(len(state) for path in result['paths'] for state in path)
        assert lengths == [d+1, d+1] and coordinates == 2*d*(d+1)
        storage.append({'d':d, 'path_state_count':sum(lengths), 'coordinate_entries':coordinates, 'formula':2*d*(d+1)})

    blocks = [(i,) for i in range(4)]+list(it.combinations(range(4), 2))
    result = module.bounds((module.K2,)*4, ((0, 0),)*4, {}, (0,)*4, (1,)*4, blocks, False)
    entries = sum(len(p['envelope']) for p in result['projected'])
    key_coordinates = sum(len(u) for p in result['projected'] for u, _ in p['envelope'])
    assert (entries, key_coordinates, entries+key_coordinates) == (32, 56, 88)
    retained = {'blocks':len(blocks), 'entries':entries, 'key_coordinates':key_coordinates,
                'value_and_key_slots':entries+key_coordinates,
                'largest_single_envelope_entries':max(len(p['envelope']) for p in result['projected'])}

    unary = ((0, 0),)*6
    pairs = {(0, j):((0, 3), (1, 0)) for j in range(1, 6)}
    natural = traced_elimination(module, unary, pairs)
    new_to_old = (1, 2, 3, 4, 5, 0)
    new_unary, new_pairs = relabel(unary, pairs, new_to_old)
    leaf_first = traced_elimination(module, new_unary, new_pairs)
    assert natural['statistics']['maximum_bucket_scope'] == 6
    assert leaf_first['statistics']['maximum_bucket_scope'] == 2
    assert natural['accounting']['active_list_factor_visits'] == 62
    assert natural['accounting']['active_list_coordinate_comparisons'] == 62
    assert leaf_first['accounting']['active_list_factor_visits'] == 102
    assert leaf_first['accounting']['active_list_coordinate_comparisons'] == 122
    all_scores = []
    for old_state in it.product((0, 1), repeat=6):
        new_state = tuple(old_state[i] for i in new_to_old)
        value = direct_value(unary, pairs, old_state)
        assert value == direct_value(new_unary, new_pairs, new_state)
        all_scores.append(value)
    assert natural['value'] == leaf_first['value'] == max(all_scores) == 15
    # Every conditioned envelope value is also invariant under the full map.
    old_to_new = {old:new for new, old in enumerate(new_to_old)}
    conditioned_checks = 0
    for old_block in [(0,), (0, 2)]:
        for assignment in it.product((0, 1), repeat=len(old_block)):
            fixed = dict(zip(old_block, assignment))
            mapped = {old_to_new[i]:v for i, v in fixed.items()}
            assert module.max_sum(unary, pairs, fixed)[0] == module.max_sum(new_unary, new_pairs, mapped)[0]
            conditioned_checks += 1
    order = {'natural':natural, 'relabeled_leaf_first':leaf_first, 'new_to_old':new_to_old,
             'exact_field_bijection_checks':len(all_scores), 'conditioned_checks':conditioned_checks,
             'qualification':'The original API has no order argument; this diagnostic consistently relabels its input.'}

    graphs, unary0 = (module.P3, ((), ())), ((2, 0, 2), (0, 100))
    x, y = (0, 0), (2, 0)
    raw = module.bounds(graphs, unary0, {}, x, y, [(0,)], False)
    trimmed_input = restrict_components(graphs, unary0, {}, x, y)
    trimmed = module.bounds(*trimmed_input, [(0,)], False)
    assert raw['projected'][0]['capacity'] == 100
    assert trimmed['projected'][0]['capacity'] == 0
    assert raw['capacity_bounds'] == trimmed['capacity_bounds'] == [0, 0]
    try:
        restrict_components(graphs, unary0, {}, x, (2, 1))
        raise AssertionError('Caller did not reject incompatible target')
    except ValueError:
        pass
    restriction = {'raw_envelope_capacity':raw['projected'][0]['capacity'],
                   'restricted_envelope_capacity':trimmed['projected'][0]['capacity'],
                   'raw_bounds':raw['capacity_bounds'], 'restricted_bounds':trimmed['capacity_bounds'],
                   'restricted_factor_sizes':list(map(len, trimmed_input[0])),
                   'caller_rejects_incompatible_target':True}

    held = json.loads((ORIGINAL/'results.json').read_text())['named_examples']
    named = {}
    fixtures = {
        'strict_improvement': ((module.P3, module.K2), ((2, 0, 2), (0, 2)), {(0, 1):((0, 0), (0, -3), (0, 0))}, (0, 0), (2, 0), [(0,)]),
        'singleton_projection_failure': ((module.K2, module.K2), ((0, 0), (0, 0)), {(0, 1):((1, 0), (0, 1))}, (0, 0), (1, 1), [(0,), (1,)]),
    }
    for label, fixture in fixtures.items():
        current = module.bounds(*fixture, True)
        for key in ('capacity_bounds', 'barrier_bounds', 'global_capacity_bounds', 'global_barrier_bounds'):
            assert current[key] == [Q(v) for v in held[label][key]]
        named[label] = {k:current[k] for k in ('capacity_bounds','barrier_bounds','global_barrier_bounds','exact_capacity','exact_barrier')}

    q2 = set()
    for u, h in it.product(it.product((-1, 1), repeat=4), it.product((-1, 0, 1), repeat=4)):
        q2.add(tuple(u[a]+u[2+b]+h[2*a+b] for a, b in it.product((0, 1), repeat=2)))
    q3 = set()
    for k in range(32):
        vals = [Q(((k+3)*(i+5)+i*i)%7-3, 2+(i%3)) for i in range(18)]
        u = tuple(tuple(vals[2*i:2*i+2]) for i in range(3))
        p = {ij:tuple(tuple(vals[6+4*t+2*a+b] for b in range(2)) for a in range(2))
             for t, ij in enumerate(it.combinations(range(3), 2))}
        q3.add(tuple(direct_value(u, p, state) for state in it.product((0, 1), repeat=3)))
    assert len(q2) == 929 and len(q3) == 7
    coverage = {'review_Q2_parameter_inputs':1296, 'review_Q2_distinct_score_fields':len(q2),
                'review_Q3_parameter_inputs':32, 'review_Q3_distinct_score_fields':len(q3),
                'scope':'Generator coverage only, not a repeated graph benchmark'}
    return {'path_storage':storage, 'retained_envelopes':retained, 'order_and_bookkeeping':order,
            'caller_component_restriction':restriction, 'preserved_named_results':named, 'coverage_qualification':coverage}


def main():
    assert hash_file(SOURCE) == CODE_SHA and hash_file(REVIEW) == REVIEW_SHA
    protected = [SOURCE, REVIEW, ORIGINAL/'claim_and_proof.md', ORIGINAL/'freeze.json', ORIGINAL/'results.json',
                 ORIGINAL/'contract.json', ORIGINAL/'primary_prior.md',
                 ROOT/'outputs/synonymous-rna-accessibility/src/product_closure.py']
    own = [HERE/name for name in ('claim_and_proof.md', 'complexity_contract.md', 'correction_ledger.md',
                                  'protocol.json', 'make_revision.py', 'targeted_regression.py',
                                  'targeted_regression_v2.py', 'make_trace_correction.py', 'trace_erratum.md')]
    inputs = protected+own
    before = {str(p.relative_to(ROOT)):hash_file(p) for p in inputs}
    freeze_path, out = HERE/'freeze_v2.json', HERE/'results_v2.json'
    if freeze_path.exists() or out.exists():
        raise FileExistsError('Refusing to overwrite revision freeze or result')
    started = datetime.now(timezone.utc).isoformat()
    dump(freeze_path, {'created_before_run':started, 'input_sha256':before,
                       'unchanged_original_code':True, 'review_sha256':REVIEW_SHA})
    spec = importlib.util.spec_from_file_location('a3_held_accounting_diagnostic', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    began, failure = perf_counter(), None
    try:
        results = suite(module)
        assert perf_counter()-began < 60
        results['status'] = 'targeted_regressions_passed'
    except Exception as exc:
        results = {'status':'failed', 'error':f'{type(exc).__name__}: {exc}'}
        failure = results['error']
    elapsed = perf_counter()-began
    after = {str(p.relative_to(ROOT)):hash_file(p) for p in inputs}
    if before != after:
        failure = 'Input hashes changed'
        results['status'] = 'inputs-changed'
    results['runtime_seconds'] = elapsed
    results['provenance'] = 'Author correction diagnostics importing held implementation; distinct tiny direct field checks, not a new independent review.'
    dump(out, results)
    repo = ROOT/'outputs/synonymous-rna-accessibility'
    commit = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    dirty = bool(subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip())
    manifest = {
        'schema_version':2, 'claim_id':'A3_ACCOUNTING_CORRECTION_V2', 'repository':{'commit':commit,'dirty':dirty},
        'command':[sys.executable,str(Path(__file__).resolve())],
        'environment':{'software':[{'name':'Python','version':platform.python_version()}],
                       'hardware':platform.platform()+'; '+platform.machine()},
        'mathematics':{'assertion_tested':'Targeted exact accounting, order, component-restriction and preserved-result assertions in protocol.json',
                       'coefficient_domain':'Fraction and exact integer counts',
                       'conventions':'Preserved source, full-coordinate paths, all envelope outputs retained, natural order',
                       'inputs':list(before),'bounds':{'maximum_storage_diagnostic_dimension':64,'maximum_exact_score_bijection_vertices':64},
                       'non_claims':['New algorithm','Independent review','Universal proof from tests','Biological results']},
        'randomness':{'used':False,'generator':'','seed':None},
        'run':{'started_at':started,'runtime_seconds':elapsed,'exit_status':int(failure is not None),
               'status':'completed' if not failure else results['status'],
               'resource_limits':{'memory_bytes':None,'cpu_seconds':60,'max_cores':1,'max_threads':1}},
        'outputs':[{'path':str(out.relative_to(ROOT)),'sha256':hash_file(out),'kind':'result'}],
        'checks':['Original sources and receipts unchanged','Exact coordinate counts','Exact relabeling invariance','Named results unchanged'],
        'result':'Targeted regressions passed; corrected complexity contract is in separate revision' if not failure else failure,
        'residual_risks':['Cubic MaxCut external theorem remains a named dependency','No exhaustive novelty search','Slot bounds are not byte measurements'],
        'input_artifacts':[{'path':p,'sha256':h,'sha256_after':after[p]} for p,h in before.items()],
        'declared_results':[str(out.relative_to(ROOT))],
    }
    dump(HERE/'manifest_v2.json', manifest)
    print(json.dumps({'status':results['status'],'seconds':elapsed,'failure':failure}))
    return int(failure is not None)


if __name__ == '__main__':
    raise SystemExit(main())
