# Prior boundary and exact observation model

This document and the protocol are written before computing the new cost outcomes.

## Closest inspected prior

Deshpande, Hellerstein and Kletenik define stochastic Boolean function evaluation with priced bit observations under a product distribution, minimizing expected cost. That is precisely the singleton formulation here, with endpoint connectivity as the Boolean function. Their approximation results are not needed to justify our exhaustive reference calculation. [Author preprint, abstract](https://arxiv.org/abs/1303.0726v2).

Allen, Hellerstein, Kletenik and Unluyurt explicitly define certificates, adaptive decision trees and unequal observation costs in Section 2. Section 6.3 uses a dynamic programme for minimum expected decision-tree cost. It also discusses cheapest-variable-first as an established simple baseline. We use a complete partial-state table on six bits, not their more efficient specialized representation. The grouped-action recurrence below is ordinary finite decision analysis, not a claimed new extension theorem. [Author manuscript, Sections 2 and 6.3](https://www.cs.cmu.edu/afs/cs/user/srallen/www/papers/dnfeval.pdf), final paper DOI [10.1007/s00453-015-0092-9](https://doi.org/10.1007/s00453-015-0092-9).

The existing project's LazySP comparison is an adaptation from edge queries to vertex observations. We import its forward and path/cut selectors unchanged. This audit does not assert the motion-planning guarantees apply to vertex observations, batch actions or unequal costs. The new observation prices are illustrative rational numbers, not measured experimental costs.

## Correctness of the exact reference

There is a finite set of hidden Boolean worlds with a specified prior. A partial state records deterministic observations, and an action reveals a fixed subset of coordinates for a known strictly positive price. Actions with no unobserved member can be removed: they provide no information and cannot improve an optimum. A history's posterior is determined by its observed coordinates. In the product-prior model, unobserved coordinates retain independent Bernoulli probabilities, including after adaptive queries and batches. We condition on observed values, not on an unobserved connectivity label.

Let `V(s)` be the least expected additional cost. It is zero when connectivity is constant on all worlds consistent with state `s`. Otherwise,

`V(s) = min_a [c(a) + sum_y P(y | s,a) V(s extended by y)]`.

Every available action reveals at least one new coordinate. Its descendants therefore have fewer unknown coordinates, so induction from complete states proves the recurrence. Any admissible adaptive strategy begins with some action and has continuation cost at least the corresponding descendant optimum. This gives the lower bound for every action. Choosing a minimizing action and then the minimizing descendant policies attains the bound. Randomization is unnecessary because a mixture of first-action values cannot improve their minimum. At most six successful actions are needed here because all singletons are always available. The recurrence is exponential in variable count; no scalable general optimizer is claimed.

This proof also covers a finite correlated prior if posterior branch probabilities are correctly computed from the entire compatible-world support. The implemented benchmark uses only the specified independent priors. It does not test correlated priors. Full support (`0 < p < 1`) means deterministic certificates cannot exploit zero-probability completions. An exact connection certificate is a positive path; an exact separation certificate excludes every possible path. Direct completion enumeration is a separate check of these labels.

Costs are stored in quarter units as integers and expectations use rational arithmetic. A batch with one known member retains its original full price. The batch has no hidden setup fee, capacity limit, delay, stochastic failure, repeated-measurement benefit or noise. A comparison of action counts is not a comparison of paid costs or wall-clock efficiency. Existing singleton policies may ignore available batches; their costs are valid upper bounds but are not described as cost-adapted policies.

Adding optional batch actions cannot increase the optimum because all prior actions remain available. A batch can still be inferior to sequential testing, since it commits payment for two observations before a first answer may establish a certificate. There is no assumption that every batch must help.

## Independent finite checks

The production value recurrence uses partial-state status and action outcome distributions. The status oracle enumerates every full truth world using its own graph traversal, then checks the original module's lower/upper graph certificate on all 729 states. Expected policy costs are recomputed by simulating every full world and weighting its complete trajectory, independently of the Bellman recurrence.

For a four-cycle with opposite endpoints observed present, the Boolean answer is the OR of its two internal vertices. An independent routine enumerates all deterministic decision trees, with no memoized optimal-substructure recurrence: every first action, every outcome partition and every combination of descendant trees is retained. The minimum enumerated expected cost is compared with the dynamic programme for every two-bit cost vector, three priors and two action sets. This is algorithmic cross-checking by the same author, not a separately authored review.

For Q3, every saved state value is compared with every legal action's one-step expected value, and the selected action must attain equality. A policy's enumerated expected cost must equal the recorded value. These checks support the implementation within the exhaustive finite domain; the induction proves the mathematical recurrence.

No uncertainty interval is appropriate for these exact finite expectations. There is no sampling error, but conclusions remain conditional on the chosen graph, prior and action-price model. The original failed acquisition comparison remains unchanged and cannot be rescued by choosing a favorable row from this audit.
