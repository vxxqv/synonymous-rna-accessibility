"""Independent finite audit using world supports, integer masses and subset cuts.

No creator solver, imported acquisition helper or NetworkX operation is used.
"""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import hashlib, itertools, json, gzip, time, sys, platform
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
WORKSPACE=BASE.parents[1]
began=time.perf_counter()
started_at=datetime.now(timezone.utc).isoformat()
hashes_before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
 [BASE/'freeze.json',BASE/'cost_audit.py',BASE/'protocol.json',BASE/'prior_and_proof.md',
  BASE/'results/cases.json',BASE/'results/summary.json',BASE/'results/bellman_certificates.json.gz']}
assert hashlib.sha256((BASE/'freeze.json').read_bytes()).hexdigest()=='3686acf9a6f5c1210cff47630de0959f536d1c552d57577f7157c939bae8a9d3'
freeze=json.loads((BASE/'freeze.json').read_text())
for rel,h in freeze['input_sha256'].items():assert hashlib.sha256((WORKSPACE/rel).read_bytes()).hexdigest()==h
saved=json.loads((BASE/'results/cases.json').read_text())
rows=saved['cases'];certs=json.loads(gzip.decompress((BASE/'results/bellman_certificates.json.gz').read_bytes()))
assert len(rows)==384 and len(certs)==384
assert set(map(tuple,saved['world_order']))==set(itertools.product((0,1),repeat=6))
worlds=list(range(64));adj={v:tuple(sorted(v^(1<<b) for b in range(3))) for v in range(8)}
actions=[1<<i for i in range(6)]+[(1<<0)|(1<<5),(1<<1)|(1<<4),(1<<2)|(1<<3)]
names=['S'+str(i) for i in range(1,7)]+['B1,6','B2,5','B3,4']

def conn(retained):
    if not (retained&1 and retained&128):return False
    seen=1;todo=[0]
    while todo:
        for v in adj[todo.pop()]:
            if retained>>v&1 and not seen>>v&1:seen|=1<<v;todo.append(v)
    return bool(seen&128)

labels={w:conn(1|128|sum(((w>>i)&1)<<(i+1) for i in range(6))) for w in worlds}
states=[]
for observed in range(64):
    for positives in range(64):
        if positives&~observed==0:states.append((observed,positives))
assert len(states)==729
supports={(o,z):tuple(w for w in worlds if w&o==z) for o,z in states}
terminal={(o,z):(labels[s[0]] if len({labels[w] for w in s})==1 else None) for (o,z),s in supports.items()}

def statekey(o,z):return ''.join(str((z>>i)&1) if o>>i&1 else '?' for i in range(6))
def possible_vertices(o,z):return 1|128|sum((1<<(i+1)) for i in range(6) if not(o>>i&1) or z>>i&1)
def path(allowed):
    todo=[(0,)];seen={0}
    for seq in todo:
        if seq[-1]==7:return seq
        for v in adj[seq[-1]]:
            if allowed>>v&1 and v not in seen:seen.add(v);todo.append(seq+(v,))
    raise AssertionError('unresolved must have possible path')

def old_selector(o,z,cut):
    # Singleton-policy query count is number of observed internal bits.
    if cut and o.bit_count()%2:
        unseen=[v for v in range(1,7) if not(o>>(v-1)&1)]
        for size in range(1,len(unseen)+1):
            for candidate in itertools.combinations(unseen,size):
                removed=sum(1<<v for v in candidate)
                if not conn(possible_vertices(o,z)&~removed):return candidate[0]-1
        raise AssertionError('no unknown cut')
    seq=path(possible_vertices(o,z));unknown=[v for v in seq if v not in [0,7] and not(o>>(v-1)&1)]
    if not cut:return unknown[0]-1
    return min(unknown,key=lambda v:(abs(2*seq.index(v)-(len(seq)-1)),v))-1

selector={(o,z,cut):old_selector(o,z,cut) for o,z in states if terminal[o,z] is None for cut in [False,True]}
counts={'independent_status_states':729,'optimal_roots':0,'all_state_values':0,'selected_actions':0,'world_trajectories':0,'policy_expectations':0,'partially_observed_batch_actions_replayed':0,'full_batch_charges_replayed':0}
examples=[];results=[]
for row,cs in zip(rows,certs):
    i=row['case_id'];assert cs['case_id']==i
    costs=tuple(row['singleton_costs']);p=F(row['p']);batch=row['mode']=='singleton_plus_pairs';assert p in [F(1,4),F(1,2),F(3,4)]
    prices=list(map(F,costs))+[F(3,4)*(costs[0]+costs[5]),F(3,4)*(costs[1]+costs[4]),F(3,4)*(costs[2]+costs[3])]
    acts=tuple(range(9 if batch else 6))
    # Absolute integer masses, posterior calculated by support normalization.
    numerator,denominator=p.numerator,p.denominator
    mass={w:numerator**w.bit_count()*(denominator-numerator)**(6-w.bit_count()) for w in worlds}
    state_mass={s:sum(mass[w] for w in ws) for s,ws in supports.items()}
    @lru_cache(None)
    def decision(o,z):
        if terminal[o,z] is not None:return (F(0),None)
        options=[]
        for a in acts:
            new=actions[a]&~o
            if not new:continue
            groups={}
            for w in supports[o,z]:groups[w&new]=groups.get(w&new,0)+mass[w]
            q=prices[a]
            for bits,m in groups.items():q+=F(m,state_mass[o,z])*decision(o|new,z|bits)[0]
            options.append((q,a))
        return min(options)
    value,chosen=decision(0,0)
    assert value==F(row['optimal_expected_cost']),(i,value,row['optimal_expected_cost'])
    counts['optimal_roots']+=1
    for key,sval,sact in cs['states']:
        o=sum(1<<j for j,c in enumerate(key) if c!='?');z=sum(1<<j for j,c in enumerate(key) if c=='1')
        v,a=decision(o,z);assert v==F(sval),(i,key,v,sval)
        assert (names[a] if a is not None else None)==sact,(i,key,a,sact)
        counts['all_state_values']+=1
        if a is not None:counts['selected_actions']+=1
    means={}
    for policy,record in row['policies'].items():
        expected=F(0);na=F(0);nb=F(0)
        for truth,wrecord in zip(saved['world_order'],record['world_results']):
            w=sum(v<<j for j,v in enumerate(truth));o=z=0;paid=F(0);selected=[];bits_seen=0
            while terminal[o,z] is None:
                if policy=='exact_bayes_optimal':a=decision(o,z)[1]
                elif policy=='unchanged_lazy_forward_singletons':a=selector[o,z,False]
                elif policy=='unchanged_path_cut_singletons':a=selector[o,z,True]
                elif policy=='cheapest_cost_per_unseen_bit':
                    a=min((a for a in acts if actions[a]&~o),key=lambda a:(prices[a]/(actions[a]&~o).bit_count(),prices[a],a))
                else:raise AssertionError(policy)
                new=actions[a]&~o;assert new
                if a>=6:
                    counts['full_batch_charges_replayed']+=1
                    if new.bit_count()==1:counts['partially_observed_batch_actions_replayed']+=1
                paid+=prices[a];selected.append(names[a]);bits_seen+=new.bit_count();o|=new;z|=w&new
            assert terminal[o,z]==labels[w]
            assert [str(paid),selected,bits_seen]==wrecord,(i,policy,truth,[str(paid),selected,bits_seen],wrecord)
            prob=F(mass[w],denominator**6);expected+=prob*paid;na+=prob*len(selected);nb+=prob*bits_seen
            counts['world_trajectories']+=1
        assert expected==F(record['expected_cost']) and na==F(record['expected_actions']) and nb==F(record['expected_revealed_bits'])
        assert expected-value==F(record['regret_to_optimum'])
        means[policy]=str(expected);counts['policy_expectations']+=1
    results.append({'case_id':i,'optimal_expected_cost':str(value),'policy_expected_costs':means})
    if costs==(1,)*6:examples.append({'p':str(p),'batch':batch,'value':str(value),'chosen':names[chosen]})

expectedgrid=set(itertools.product(itertools.product((1,4),repeat=6),['1/4','1/2','3/4'],['singleton','singleton_plus_pairs']))
observedgrid={(tuple(r['singleton_costs']),r['p'],r['mode']) for r in rows}
assert expectedgrid==observedgrid and len(observedgrid)==384
# Pricing and stopping adversaries that are not necessarily selected optimally.
partial_batch_price=F(3,4)*(4+1)
assert partial_batch_price==F(15,4) # one unseen member does not receive a price reduction
assert partial_batch_price>F(1)
allknown_actions=[a for a in range(9) if actions[a]&~63];assert allknown_actions==[]
assert terminal[0,0] is None
assert sum(mass.values())==denominator**6
zero_probability_note='All frozen priors have full support. General correlated-prior conditioning is meaningful only at positive-mass histories; zero-mass branches can be omitted from the expectation, without turning prior support into a universal graph certificate.'
assert hashes_before=={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in hashes_before}
receipt={'status':'pass','assertion_tested':'Independent support-normalized exact Bellman values, lexicographic optimal actions and separately reconstructed policy trajectories agree throughout the 384 frozen Q3 cases.','counts':counts,'equal_price_examples':examples,'zero_probability_scope':zero_probability_note,'boundary_checks':{'partial_pair_price_4_and_1_one_known':'15/4, no discount for known member','fully_observed_batch_excluded':True,'endpoints_not_queried_or_charged':True,'root_unresolved':True},'comparison_results':results,'inputs_sha256':hashes_before,'input_hashes_unchanged':True,'command':[sys.executable,str(Path(__file__).resolve())],'python':platform.python_version(),'runtime_seconds':time.perf_counter()-began,'independence':'Separately authored implementation; shared project history and creator source/proof were read. No creator or acquisition function called; support-mass probabilities and exhaustive subset separators replace creator transitions and network flow.','limitations':['Exact finite model only; no laboratory costs, noisy observations, large-graph scalability or priority claim.','This is an implementation and proof review by a separate agent, not a fresh-context mathematical referee or independent experimental dataset.']}
receipt['started_at']=started_at
(HERE/'independent_results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['comparison_results','inputs_sha256']},indent=2))
