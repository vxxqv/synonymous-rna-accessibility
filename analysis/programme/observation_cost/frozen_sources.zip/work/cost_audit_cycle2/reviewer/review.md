# Independent bounded observation-cost audit

**Primary verdict: computationally verified only in the stated range.** All 384 frozen rational Q3 optima, all 279936 saved partial-state values, all 134784 saved nonterminal minimizing actions, all 1536 policy expectations and all 98304 full-world policy trajectories agree with a separately authored exact reference. No counterexample or charging error was found. The Bellman induction is correct for the stated finite full-support deterministic-observation model. No novel algorithm or experimental-efficiency conclusion follows.

## Claim card

The graph is the three-dimensional binary cube on vertices 0 through 7. Vertices 0 and 7 are known present and free of query charges. The six internal vertices have independent equal Bernoulli probability p in {1/4,1/2,3/4}. Singleton costs run through all 64 vectors in {1,4}^6. Two legal action sets are compared: the six singletons, or those plus fixed pairs {1,6}, {2,5}, {3,4}. A pair costs 3/4 of its original singleton-cost sum, including when one member is already observed. Fully observed actions are unavailable. Observations are noiseless and a policy must stop exactly at a universal graph certificate. Action order resolves exact-cost ties.

The audited freeze is SHA256 `3686acf9a6f5c1210cff47630de0959f536d1c552d57577f7157c939bae8a9d3`. Its four input hashes match current bytes. The repository revision recorded in the freeze is `e9846dca9f74b2c5c34e984eed970e996b9df2bf`. The creator's files, freeze, results and proof were not edited or rerun.

## Dependency graph and proof obligations

1. Cube adjacency and six unknown-bit interpretation determine 64 full worlds.
2. Full-world graph traversal determines the Boolean connectivity function.
3. A partial state stops if and only if this function is constant on all compatible worlds.
4. The independent prior assigns each compatible world positive exact mass.
5. An action's conditional outcomes partition compatible worlds and reveal at least one new bit.
6. Its value is the full action charge plus posterior-weighted descendant values.
7. Induction in the number of unknown bits proves the Bellman minimum is attainable and no admissible adaptive policy is cheaper.
8. Enumerated world trajectories and rational masses yield policy expectations; aggregation yields the reported fixed-grid summaries.

Leaves 1 through 6 are definitions/conventions with separately implemented checks. Step 7 is a finite internal proof, not dependent on the approximation theorems cited as prior background. Step 8 is finite exact computation. No external theorem is load-bearing for these correctness conclusions; novelty attribution was not re-audited here.

| Obligation | Verdict | Evidence |
| --- | --- | --- |
| Grid covers exactly 64 costs x 3 priors x 2 modes, without duplicates or exclusions | Passed | Independent comparison with the complete Cartesian case-key set |
| Endpoints known present, unqueried and uncharged | Passed | Independent worlds always include endpoints; all legal masks cover only the six internal vertices |
| All 729 terminal/unresolved labels | Passed | Independent graph traversal over compatible full worlds |
| Conditional probabilities after adaptive singletons or pairs | Passed | Independent normalization of integer world masses rather than the creator's per-action Bernoulli branch formula |
| Full pair payment and atomic two-bit revelation | Passed | Every world action replayed with its original full price before terminal checking |
| Pair with one unknown member | Passed | 10384 such recorded actions independently replayed; no price reduction applied |
| Fully known pair or repeated no-information query | Passed | No legal mask with zero newly revealed bits, and no unchanged state transition |
| Optimal Bellman values and deterministic ties | Passed | Every saved state and selected action independently matched using exact fractions |
| Original forward/path-cut semantics | Passed in Q3 domain | Independent lexicographic BFS and exhaustive subset separators; no imported acquisition or NetworkX routine used |
| Expected costs, counts, regrets and summary comparisons | Passed | All full-world trajectories and exact weighted aggregates agree |
| Correlated or zero-support extension | Not executed | Requires the posterior and zero-mass-history qualification below |
| Noise, assay economics, large graphs or new efficiency guarantee | Out of scope | Not implied by this finite deterministic model |

## Independent formulation and observed execution

`independent_reference.py` does not import or call the creator's solver, certificate function, transition builder or original policy module. It constructs cube adjacency directly from binary bit flips and determines connectivity by its own graph traversal. A state uses an observed-coordinate mask and a positive-value mask. Consistent full worlds, their absolute integer masses and their observation-outcome partitions are constructed directly. The conditional probability for a branch is its support mass divided by its parent support mass. This independently checks the product-probability shortcut in the creator's implementation.

For the unchanged path/cut policy, the reference enumerates every subset of unknown vertices in increasing cardinality and lexicographic order to find the chosen minimum separator. This replaces the creator's weighted node-splitting/min-cut implementation. Forward and midpoint path queries are reconstructed from independent sorted BFS. Thus matching trajectories test both the selector conventions and the accounting, rather than merely summing creator action lists.

The command was:

```powershell
work/env/Scripts/python.exe work/cost_audit_cycle2/reviewer/independent_reference.py
```

It completed with exit 0 under Python 3.12.14 in 6.48 seconds. Exact fractions are used throughout. No random seed or floating comparison is involved. All creator input/result hashes recorded by the reference remained unchanged afterward. The independent script's SHA256 is `30dcc83f2a5973211baee0d4c41c51c2c4779154c8d8f1466c5ad12062bc809c`; `independent_results.json` has SHA256 `6718a32c31edc35dab1b5cdfdc30043bb7a3a901a597df483485654d61df5b44`. The result file records commands, software, range, counters, source hashes, per-case expectations and limitations. `summary_verification.json` separately records successful exact reaggregation of the saved summary fields from independently verified case expectations.

## Decisive checks and boundary interpretation

For all singleton costs one, the reference independently obtains:

| p | Singleton optimum | Optional-pair optimum | Initial optimal action with pairs |
| --- | --- | --- | --- |
| 1/4 | 1873/512 | 873/256 | B1,6 |
| 1/2 | 27/8 | 53/16 | B1,6 |
| 3/4 | 1359/512 | 1359/512 | S1 |

These check both a strict optional-batch improvement and a tie where buying a batch first is unnecessary. All 192 paired action-set comparisons agree: 184 strict improvements, eight ties, mean grid gain 120137/393216 and maximum 139/128. The path/cut versus forward totals independently remain 176 wins, 32 ties and 176 losses; they duplicate the 192 singleton comparisons because both policies ignore batches. The cheapest-per-unseen-bit baseline remains strictly suboptimal in all 384 cases. None of these finite-grid statements is a population estimate.

In total, 36868 batch actions were replayed across the stored world trajectories. Full price is paid even if observation of one member alone would have sufficed to certify the world; no within-batch early refund is permitted. A pair whose assigned singleton costs are 4 and 1 still costs 15/4 if only one coordinate is unknown. If the unknown coordinate is the cost-1 member, this is worse than its singleton; if it is the cost-4 member, the same full batch price can still be slightly cheaper. The implementation does not silently prohibit that latter legitimate use.

The creator's branch formula has no missing binomial coefficient: each labelled assignment is separately enumerated, so assignments with the same number of ones occur as separate branches. Multiplying an individual branch by a binomial coefficient would double-count probability. The cheap-baseline comparison in integer quarter-units differs from actual paid cost by a common positive factor, so its ordering and ties are preserved.

Every frozen p is strictly between zero and one. Thus all 64 worlds and all compatible partial states have positive prior mass, including counterfactual states not reached by a particular selected policy. There is no zero-denominator conditional probability in this audit. The number of singleton observations equals the number of observed internal bits for the two unchanged policies, so using that count as the original selector's step parity is correct. Their lack of batch/cost adaptation is a stated comparator limitation, not an invalid action charge.

## Precise remaining limit

The generic correlated-prior paragraph must be read on positive-probability histories. For a finite prior with zero-mass worlds, conditional distributions are undefined at zero-mass histories; those branches can be omitted from expected-cost sums or assigned arbitrary counterfactual continuation rules. This does not authorize stopping from prior support alone when the task still demands a universal graph certificate over all logically compatible worlds. The stated full-support grid avoids this distinction. No numeric correction or rerun of its 384 cases is required.

The finite Bellman induction is sound because every allowed action reveals a new coordinate, all prices are fixed and positive, and future permissible actions and charges are determined by the observed state. Adaptive selection gives no hidden observation of unqueried bits. A randomized first action yields a convex combination of deterministic action values and cannot improve the minimum. These arguments do not survive arbitrary history-dependent discounts, noisy observation, correlated posterior approximations or a changed stopping criterion without additional work.

Strongest safe conclusion: the completed study is an exact and independently corroborated finite expected-cost comparison for its frozen model. No additional experiment, expanded synthetic grid or novelty assertion is needed to support that conclusion. A correlated/noisy/empirical extension remains a separate unexecuted question.

## Review provenance

This is a separately authored adversarial implementation and proof review by an agent that did not author the cost study. It inherits project history and read the creator's current source, proof and outputs, so it is not a blinded fresh-context referee report. Independent representation, probabilities, graph traversal and separator calculation reduce shared-implementation risk; agreement alone does not replace the proof. All reviewer writes are confined to `work/cost_audit_cycle2/reviewer/`. No creator file, computational repository, manuscript or external service was mutated, and no commit was made.
