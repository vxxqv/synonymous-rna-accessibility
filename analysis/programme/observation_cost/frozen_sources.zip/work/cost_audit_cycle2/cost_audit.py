"""Frozen finite observation-cost audit. All writes stay beside this script."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as Q
from functools import lru_cache
import gzip
import hashlib
import importlib.util
import itertools
import json
import platform
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
REPO = WORKSPACE / 'outputs/synonymous-rna-accessibility'
ORIGINAL = REPO / 'src/acquisition.py'
INPUTS = (Path(__file__).resolve(), HERE/'protocol.json', HERE/'prior_and_proof.md', ORIGINAL)
spec = importlib.util.spec_from_file_location('frozen_original_acquisition', ORIGINAL)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
POLICIES = ('exact_bayes_optimal', 'unchanged_lazy_forward_singletons',
            'unchanged_path_cut_singletons', 'cheapest_cost_per_unseen_bit')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n', encoding='utf-8')


def key(state):
    return ''.join('?' if x == -1 else str(x) for x in state)


def connected(adjacency, retained, start, end):
    """Independent full-world DFS, with no original certificate helper."""
    seen = {start}
    stack = [start]
    while stack:
        u = stack.pop()
        for v in adjacency[u]:
            if retained[v] and v not in seen:
                seen.add(v)
                stack.append(v)
    return end in seen


class GraphModel:
    def __init__(self, adjacency, endpoints, unknown, pairs):
        self.adjacency = tuple(tuple(sorted(x)) for x in adjacency)
        self.endpoints, self.unknown = endpoints, tuple(unknown)
        self.n = len(unknown)
        self.root = (-1,)*self.n
        self.pairs = tuple(tuple(self.unknown.index(v) for v in pair) for pair in pairs)
        self.action_bits = tuple((i,) for i in range(self.n)) + self.pairs
        self.action_names = tuple('S'+str(v) for v in unknown) + tuple(
            'B'+','.join(str(v) for v in pair) for pair in pairs)
        self.worlds = tuple(itertools.product((0, 1), repeat=self.n))
        self.truth = {w: connected(self.adjacency, self.expand(w), *endpoints) for w in self.worlds}
        self.states = tuple(sorted(itertools.product((-1, 0, 1), repeat=self.n),
                                   key=lambda s: (s.count(-1), s)))
        self.status, self.transitions, self.original_choices = {}, {}, {}
        self.completion_checks = 0
        for state in self.states:
            values = set()
            for w in self.worlds:
                if all(a == -1 or a == b for a, b in zip(state, w)):
                    values.add(self.truth[w])
                    self.completion_checks += 1
            self.status[state] = next(iter(values)) if len(values) == 1 else None
            label = original.certificate(self.adjacency, self.expand(state), *endpoints)
            expected = 'unresolved' if len(values) == 2 else ('connected' if True in values else 'separated')
            assert label == expected, (state, label, expected)
            self.transitions[state] = {}
            if self.status[state] is not None:
                continue
            for action, bits in enumerate(self.action_bits):
                newly = tuple(i for i in bits if state[i] == -1)
                if not newly:
                    continue
                branches = []
                for outcome in itertools.product((0, 1), repeat=len(newly)):
                    child = list(state)
                    for i, value in zip(newly, outcome):
                        child[i] = value
                    branches.append((tuple(child), sum(outcome), len(newly)))
                self.transitions[state][action] = tuple(branches)
            for policy in ('lazy_forward', 'path_cut'):
                vertex = original.choose_query(self.adjacency, self.expand(state), *endpoints,
                                               policy, self.n-state.count(-1), None)
                self.original_choices[state, policy] = self.unknown.index(vertex)

    def expand(self, state):
        answer = [1]*len(self.adjacency)
        for v, bit in zip(self.unknown, state):
            answer[v] = bit
        return answer

    def costs(self, singles):
        return tuple(4*c for c in singles) + tuple(3*sum(singles[i] for i in pair) for pair in self.pairs)


def solve(model, singles, p, batch):
    """Exact bottom-up Bellman reference; prices are integer quarter units."""
    action_costs = model.costs(singles)
    action_limit = len(model.action_bits) if batch else model.n
    branch_probability = {(k, ones): p**ones*(1-p)**(k-ones) for k in (1, 2) for ones in range(k+1)}
    value, policy, checks = {}, {}, 0
    for state in model.states:
        if model.status[state] is not None:
            value[state] = Q(0)
            continue
        candidates = []
        for action, branches in model.transitions[state].items():
            if action >= action_limit:
                continue
            q = Q(action_costs[action], 4) + sum(
                (branch_probability[k, ones]*value[child] for child, ones, k in branches), Q(0))
            candidates.append((q, action))
        value[state], policy[state] = min(candidates)
        assert all(value[state] <= q for q, _ in candidates)
        assert (value[state], policy[state]) in candidates
        checks += len(candidates)
    return value, policy, checks


def run_policy_world(model, singles, batch, policy_name, optimal_policy, truth):
    state, cost, actions, revealed = model.root, Q(0), [], 0
    all_costs = model.costs(singles)
    while model.status[state] is None:
        if policy_name == 'exact_bayes_optimal':
            action = optimal_policy[state]
        elif policy_name == 'unchanged_lazy_forward_singletons':
            action = model.original_choices[state, 'lazy_forward']
        elif policy_name == 'unchanged_path_cut_singletons':
            action = model.original_choices[state, 'path_cut']
        elif policy_name == 'cheapest_cost_per_unseen_bit':
            limit = len(model.action_bits) if batch else model.n
            action = min((a for a in model.transitions[state] if a < limit), key=lambda a: (
                Q(all_costs[a], sum(state[i] == -1 for i in model.action_bits[a])), all_costs[a], a))
        else:
            raise ValueError(policy_name)
        assert action < (len(model.action_bits) if batch else model.n)
        child = list(state)
        for i in model.action_bits[action]:
            if state[i] == -1:
                child[i] = truth[i]
                revealed += 1
        assert tuple(child) != state
        cost += Q(all_costs[action], 4)
        actions.append(model.action_names[action])
        state = tuple(child)
        assert len(actions) <= model.n
    assert model.status[state] == model.truth[truth]
    return cost, tuple(actions), revealed


def evaluate(model, singles, p, batch, policy_name, optimal_policy):
    worlds = []
    total_cost = total_actions = total_bits = Q(0)
    for truth in model.worlds:
        cost, actions, bits = run_policy_world(model, singles, batch, policy_name, optimal_policy, truth)
        weight = p**sum(truth)*(1-p)**(model.n-sum(truth))
        total_cost += weight*cost
        total_actions += weight*len(actions)
        total_bits += weight*bits
        worlds.append([str(cost), list(actions), bits])
    return {'expected_cost': str(total_cost), 'expected_actions': str(total_actions),
            'expected_revealed_bits': str(total_bits), 'world_results': worlds}


def c4_all_trees(costs, p, batch):
    """Independent brute enumeration: all decision-tree costs, no memoization."""
    worlds = tuple(itertools.product((0, 1), repeat=2))
    probabilities = {w: p**sum(w)*(1-p)**(2-sum(w)) for w in worlds}
    actions = [((0,), Q(costs[0])), ((1,), Q(costs[1]))]
    if batch:
        actions.append(((0, 1), Q(3, 4)*sum(costs)))

    def trees(support):
        labels = {any(w) for w in support}
        if len(labels) == 1:
            return [Q(0)]
        total = sum((probabilities[w] for w in support), Q(0))
        all_costs = []
        for bits, price in actions:
            groups = {}
            for w in support:
                groups.setdefault(tuple(w[i] for i in bits), []).append(w)
            if len(groups) == 1:
                continue
            children = [(sum((probabilities[w] for w in group), Q(0))/total, trees(tuple(group)))
                        for _, group in sorted(groups.items())]
            for alternatives in itertools.product(*(choices for _, choices in children)):
                all_costs.append(price + sum((mass*c for (mass, _), c in zip(children, alternatives)), Q(0)))
        return all_costs

    options = trees(worlds)
    return min(options), len(options)


def small_checks():
    model = GraphModel(((1, 3), (0, 2), (1, 3), (0, 2)), (0, 2), (1, 3), ((1, 3),))
    rows = []
    for costs, p, batch in itertools.product(itertools.product((1, 4), repeat=2), (Q(1, 4), Q(1, 2), Q(3, 4)), (False, True)):
        values, policy, checks = solve(model, costs, p, batch)
        brute, count = c4_all_trees(costs, p, batch)
        assert values[model.root] == brute
        expected = evaluate(model, costs, p, batch, 'exact_bayes_optimal', policy)
        assert Q(expected['expected_cost']) == brute
        rows.append({'costs': costs, 'p': str(p), 'batches': batch, 'expected_cost': str(brute),
                     'enumerated_trees': count, 'bellman_inequalities': checks})
    assert len(rows) == 24
    return {'cases': rows, 'status': 'all exact comparisons passed',
            'independence': 'Separate exhaustive decision-tree formulation by the same author, not a separately authored audit'}


def summarize(rows):
    result = {'cases': len(rows), 'policies': {}}
    for name in POLICIES:
        regrets = [Q(row['policies'][name]['regret_to_optimum']) for row in rows]
        ratios = [Q(row['policies'][name]['expected_cost'])/Q(row['optimal_expected_cost']) for row in rows]
        result['policies'][name] = {'optimal_ties': regrets.count(0), 'strict_losses': sum(x > 0 for x in regrets),
                                    'mean_regret_over_fixed_grid': str(sum(regrets, Q(0))/len(rows)),
                                    'maximum_regret': str(max(regrets)), 'maximum_ratio': str(max(ratios))}
    pairs = {}
    for row in rows:
        pairs.setdefault((tuple(row['singleton_costs']), row['p']), {})[row['mode']] = row
    gains = []
    for case in pairs.values():
        gain = Q(case['singleton']['optimal_expected_cost'])-Q(case['singleton_plus_pairs']['optimal_expected_cost'])
        assert gain >= 0
        gains.append(gain)
    result['optional_batch_value'] = {'pairs': len(gains), 'strict_improvements': sum(x > 0 for x in gains),
        'ties': gains.count(0), 'mean_gain_over_fixed_grid': str(sum(gains, Q(0))/len(gains)), 'maximum_gain': str(max(gains))}
    for left, right in [('unchanged_path_cut_singletons', 'unchanged_lazy_forward_singletons'),
                        ('cheapest_cost_per_unseen_bit', 'unchanged_lazy_forward_singletons')]:
        differences = [Q(row['policies'][left]['expected_cost'])-Q(row['policies'][right]['expected_cost']) for row in rows]
        result[left+'_minus_'+right] = {'wins': sum(x < 0 for x in differences), 'ties': differences.count(0),
            'losses': sum(x > 0 for x in differences), 'minimum_difference': str(min(differences)),
            'maximum_difference': str(max(differences)), 'mean_difference_over_fixed_grid': str(sum(differences, Q(0))/len(rows))}
    result['scope'] = 'Exact finite grid, not a sampled population. No confidence interval, experimental cost calibration, noisy-query result or novelty claim.'
    return result


def freeze():
    target = HERE/'freeze.json'
    if target.exists():
        raise FileExistsError('Freeze already exists; no overwrite')
    data = {'protocol': 'protocol.json', 'expected_cases': 384, 'expected_truths_per_case': 64,
            'expected_policy_expectations': 1536, 'created_before_cost_outcomes': True,
            'created_at': datetime.now(timezone.utc).isoformat(),
            'repository_commit': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
            'input_sha256': {str(p.relative_to(WORKSPACE)): digest(p) for p in INPUTS}}
    dump(target, data)
    print(json.dumps({'status': 'frozen', 'sha256': digest(target), 'expected_cases': 384}))


def run():
    freeze_file = HERE/'freeze.json'
    frozen = json.loads(freeze_file.read_text())
    for relative, expected in frozen['input_sha256'].items():
        if digest(WORKSPACE/relative) != expected:
            raise RuntimeError('Frozen input mismatch: '+relative)
    output = HERE/'results'
    if output.exists():
        raise FileExistsError('Results directory already exists; no overwrite')
    output.mkdir()
    began, start = datetime.now(timezone.utc).isoformat(), time.perf_counter()
    rows, certificates, counts = [], [], Counter()
    outcome, exit_status = 'failed', 1
    try:
        small = small_checks()
        dump(output/'c4_bruteforce.json', small)
        adjacency = tuple(tuple(j for j in range(8) if (i ^ j).bit_count() == 1) for i in range(8))
        model = GraphModel(adjacency, (0, 7), range(1, 7), ((1, 6), (2, 5), (3, 4)))
        assert len(model.states) == 729 and len(model.worlds) == 64
        counts['partial_states_checked'] = len(model.states)
        counts['completion_certificate_checks'] = model.completion_checks
        protocol = json.loads((HERE/'protocol.json').read_text())
        for costs, p, batch in itertools.product(itertools.product((1, 4), repeat=6), (Q(1, 4), Q(1, 2), Q(3, 4)), (False, True)):
            if time.perf_counter()-start > protocol['runtime_cap_seconds']:
                outcome = 'resource-limit'
                raise TimeoutError('Frozen runtime cap reached')
            values, policy, bellman_checks = solve(model, costs, p, batch)
            counts['bellman_action_inequalities'] += bellman_checks
            counts['bellman_states'] += len(values)
            case_id = len(rows)
            row = {'case_id': case_id, 'singleton_costs': costs, 'p': str(p),
                   'mode': 'singleton_plus_pairs' if batch else 'singleton',
                   'optimal_expected_cost': str(values[model.root]), 'policies': {}}
            for name in POLICIES:
                item = evaluate(model, costs, p, batch, name, policy)
                item['regret_to_optimum'] = str(Q(item['expected_cost'])-values[model.root])
                assert Q(item['regret_to_optimum']) >= 0
                if name == 'exact_bayes_optimal':
                    assert Q(item['expected_cost']) == values[model.root]
                row['policies'][name] = item
                counts['full_world_policy_checks'] += len(model.worlds)
            rows.append(row)
            certificates.append({'case_id': case_id, 'states': [
                [key(state), str(values[state]), model.action_names[policy[state]] if state in policy else None]
                for state in model.states]})
        assert len(rows) == 384
        assert counts['full_world_policy_checks'] == 384*64*4
        summary = summarize(rows)
        summary['checks'] = dict(counts)
        dump(output/'cases.json', {'world_order': model.worlds,
              'world_result_columns': ['paid_cost', 'ordered_action_names', 'newly_revealed_bits'], 'cases': rows})
        dump(output/'summary.json', summary)
        raw = json.dumps(certificates, separators=(',', ':')).encode()
        (output/'bellman_certificates.json.gz').write_bytes(gzip.compress(raw, mtime=0))
        for relative, expected in frozen['input_sha256'].items():
            assert digest(WORKSPACE/relative) == expected
        outcome, exit_status = 'completed', 0
        print(json.dumps(summary, indent=2))
    except BaseException as error:
        dump(output/'partial_results.json', {'complete_cases': len(rows), 'cases': rows, 'error': repr(error)})
        raise
    finally:
        manifest = {'schema_version': 2, 'claim_id': 'Q3_EXACT_OBSERVATION_COST_AUDIT_V1',
            'repository': {'commit': frozen['repository_commit'], 'dirty': bool(subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain'], text=True).strip())},
            'command': [sys.executable, str(Path(__file__).resolve()), '--phase', 'run'],
            'environment': {'software': [{'name': 'Python', 'version': platform.python_version()},
                {'name': 'networkx', 'version': original.nx.__version__}], 'hardware': platform.platform()+'; '+platform.machine()},
            'mathematics': {'assertion_tested': 'All 384 frozen exact expected-cost cases satisfy certificates, Bellman inequalities and full-world replay; independent C4 tree enumeration agrees',
                'coefficient_domain': 'Exact fractions; no floating point comparison', 'conventions': 'protocol.json; prior_and_proof.md',
                'inputs': ['protocol.json', 'freeze.json'], 'bounds': {'unknown_bits': 6, 'cost_vectors': 64, 'priors': 3, 'action_modes': 2},
                'non_claims': ['No new general algorithm', 'No biological or noisy measurement result', 'No general scalability or estimated assay costs']},
            'randomness': {'used': False, 'generator': '', 'seed': None},
            'run': {'started_at': began, 'runtime_seconds': time.perf_counter()-start, 'exit_status': exit_status, 'status': outcome,
                'resource_limits': {'memory_bytes': None, 'cpu_seconds': None, 'max_cores': 1, 'max_threads': 1},
                'wall_time_cap_seconds': 180},
            'outputs': [{'path': str(p.relative_to(WORKSPACE)), 'sha256': digest(p), 'kind': 'result'} for p in sorted(output.iterdir()) if p.is_file()],
            'checks': [dict(counts)], 'result': outcome, 'residual_risks': ['Conditioned on the declared graph, product priors and deterministic observation costs'],
            'input_artifacts': [{'path': relative, 'sha256': expected, 'sha256_after': digest(WORKSPACE/relative)} for relative, expected in frozen['input_sha256'].items()],
            'declared_results': [str((output/name).relative_to(WORKSPACE)) for name in
                ('cases.json', 'summary.json', 'c4_bruteforce.json', 'bellman_certificates.json.gz')],
            'freeze_sha256': digest(freeze_file)}
        dump(output/'manifest.json', manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('freeze', 'run'), required=True)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Assertions must be enabled')
    freeze() if args.phase == 'freeze' else run()
