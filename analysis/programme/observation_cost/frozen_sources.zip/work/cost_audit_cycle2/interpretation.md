# Exact observation-cost audit: completed bounded result

**Result:** all 384 frozen cases were evaluated exactly. Discounted optional pair observations improved the optimum in 184 of 192 matched action-set comparisons, but the simple price-aware baseline was never optimal. The original path/cut selector neither dominates nor is dominated by forward selection on this grid. The earlier failed acquisition benchmark is unchanged. This closes a bounded unequal-cost/group-observation investigation, not noisy measurement, calibrated assay economics or a new algorithm claim.

The new audit followed `protocol.json` and `freeze.json`, both saved before calculating its outcomes. Freeze SHA-256: `3686acf9a6f5c1210cff47630de0959f536d1c552d57577f7157c939bae8a9d3`. The computational repository was read only at revision `e9846dca9f74b2c5c34e984eed970e996b9df2bf`. All writes are confined to this directory.

## What was compared

The graph is Q3, with endpoints `000` and `111` known present. Six unknown vertices have independent presence probability `p`, taking each of `1/4`, `1/2` and `3/4`. All 64 assignments of prices in `{1,4}` were retained. The two action sets are singletons alone and singletons plus three fixed pairs: `{001,110}`, `{010,101}`, `{011,100}`. A pair costs three quarters of the sum of its original singleton prices. If one member is already known, the action still pays its full original batch price. An action revealing nothing is excluded.

The exact optimum minimizes expected **paid cost**, not the number of actions or revealed bits. Its complete partial-state value table is retained. Forward and path/cut use the original imported selectors without modification and continue to use only singleton observations even when batches are available. They are therefore clearly labelled singleton policies, not cost-adapted or batch-adapted versions. The simple cost-aware baseline chooses the lowest cost per newly observed bit, then lowest paid cost, then frozen action order. It is an illustrative reference with no claimed batch approximation guarantee.

Each policy stops only when all worlds compatible with its observations have the same connectivity answer. No score, noise, repeated-measurement rule, finite-budget guessing or biological interpretation is added. Costs are abstract units, not estimated laboratory prices.

## Exact results and failures

| Policy | Cases attaining the optimum | Cases strictly above the optimum | Largest ratio to optimum |
|---|---:|---:|---:|
| Exact Bellman reference | 384 | 0 | 1 |
| Unchanged forward, singletons | 4 | 380 | `17364/6481` |
| Unchanged path/cut, singletons | 0 | 384 | `17412/6481` |
| Cheapest cost per unseen bit | 0 | 384 | `613/325` |

The exact reference is a lower bound on every admissible adaptive strategy under this model, and its stored strategy attains the bound. It is a finite exhaustive optimizer, not an efficient general method.

Adding optional batches strictly lowered the optimal expected cost in **184 of 192** matched cost/prior cases and tied in eight. The mean reduction over this fixed, equally weighted grid was `120137/393216`, approximately 0.3055 cost units; the maximum was `139/128`, or 1.0859375. These are summaries of a chosen finite grid, not estimates for a population of experiments.

Path/cut was cheaper than forward in **176 cases**, tied in **32**, and more expensive in **176**. Since both policies ignore batches, these 384 comparisons duplicate 192 distinct singleton-policy comparisons: 88 wins, 16 ties and 88 losses. The equal-grid mean difference was `-5/128` in favor of path/cut. This is not independent evidence against the original benchmark: graph, prior weights and costs have deliberately changed. The original held-out failure is retained without retuning or reinterpretation.

The cheapest-per-unseen-bit baseline beat forward in 183 cases and lost in 201, with no ties. Its largest regret is `27/4` cost units. Cheap information need not be useful information for deciding connectivity, and batching can buy a second observation that would have been unnecessary after the first. Neither the price-aware rule nor the old selector is promoted as a discovery.

The following complete equal-price slice helps interpret the effect without selecting only successful batches. All six singleton prices are one:

| `p` | Singleton optimum | Optional-batch optimum | Forward singleton cost | Path/cut singleton cost | Cheapest-per-bit cost with batches |
|---|---:|---:|---:|---:|---:|
| `1/4` | `1873/512` | `873/256` | `1927/512` | `1891/512` | `123/32` |
| `1/2` | `27/8` | `53/16` | `55/16` | `55/16` | `15/4` |
| `3/4` | `1359/512` | `1359/512` | `1365/512` | `1377/512` | `105/32` |

At `p=3/4`, discounted batches provide no optimal expected-cost benefit in this equal-price slice. At `p=1/2`, the optimal improvement is only `1/16`, while indiscriminately favoring cheap batches costs `15/4`, exceeding both singleton selectors' `55/16`. Thus a discount alone does not identify a good acquisition policy.

For completeness, these are the global largest-regret cases, selected after the exhaustive calculation and explicitly descriptive:

- Forward and path/cut both attain their largest regret at case 341: prices `[4,4,4,1,1,1]` in vertex order `001,010,011,100,101,110`, `p=3/4`, optional batches. The optimum is `7795/2048`; forward costs `4797/512`, and path/cut costs `4791/512`.
- Cheapest-per-unseen-bit attains its largest regret at case 358: prices `[4,4,4,1,4,4]`, `p=3/4`, singletons only. It costs `1839/128` against optimum `975/128`.
- The largest optimal batch gain is cases 180 and 181: prices `[1,4,4,4,4,1]`, `p=1/4`. The optimum decreases from `1309/128` to `585/64`.

All remaining cases, including ties and losses, are in `results/cases.json`. Each policy has the cost, ordered action list and revealed-bit count for all 64 full worlds. No case was dropped.

## Correctness and provenance

The frozen run completed in 8.18 seconds, below its 180-second wall-time cap, using Python 3.12.14 and NetworkX 3.7. Expectations use exact rational arithmetic. The following checks passed:

- All 729 Q3 partial-state certificate labels agreed with direct enumeration over 4,096 compatible state/completion pairs.
- Every one of 98,304 full-world policy trajectories terminated with the correct connectivity answer.
- All 279,936 saved state values satisfied 492,480 Bellman action inequalities and equality for the stored minimizing action.
- Every exact optimum equalled the independently accumulated probability-weighted cost of its 64 full-world trajectories.
- A separate exhaustive decision-tree enumerator on C4 agreed in all 24 combinations of two-bit prices, priors and action sets. It enumerates complete trees rather than reusing the Bellman optimizer.
- Every optional-batch optimum was no larger than its matched singleton optimum.
- Frozen input hashes were unchanged after execution. The Mathbox version 2 manifest validator passed with the workspace as root.

The Bellman proof and closest-prior comparison are in `prior_and_proof.md`. The two finite implementations are by the same author; this is algorithmic cross-checking, not a claim of separately authored review. A certificate proof establishes soundness under exact observations. These checks do not establish soundness after adding noise or miscalibrated confidence intervals.

Stochastic Boolean function evaluation with unequal bit prices and product priors is established prior work. The adaptive decision-tree recurrence is standard. The concrete result here is a checked boundary on transferring the earlier unit-query conclusions to a changed observation contract. [Deshpande, Hellerstein and Kletenik](https://arxiv.org/abs/1303.0726v2); [Allen et al., Sections 2 and 6.3](https://www.cs.cmu.edu/afs/cs/user/srallen/www/papers/dnfeval.pdf).

## Reproduction and stopping decision

From the workspace, the recorded run command is:

```powershell
& work/env/Scripts/python.exe work/cost_audit_cycle2/cost_audit.py --phase run
```

The run checks `freeze.json` and refuses to overwrite an existing `results` directory. To reproduce in place, first rename the existing `results` directory to a distinct preserved name within this audit directory, then run the command again. Retain all original results and compare file contents rather than replacing the completed receipt. No publication files or repository changes were created by this audit.

The exact Bellman table is in `results/bellman_certificates.json.gz`, with deterministic compressed contents; the complete expectations and world trajectories are in `results/cases.json`; the summary, C4 checks and manifest are beside them.

**Stop here.** This supplies the requested bounded cost/group-observation investigation with both improvements and failures. No graph expansion, cost tuning or new heuristic is justified by these results. Noisy observations, repeated measurements, correlated priors and actual assay cost calibration remain unexecuted and unclaimed. A useful biological analysis still requires eligible measurements rather than another synthetic benchmark.
